# PathWise - Personalized Learning Recommendation Engine

A student-only, ML-driven personalized learning platform: React frontend,
FastAPI backend, MySQL database, and a scikit-learn-based recommendation
engine that continuously re-scores content as new activity comes in.

```
Student -> Learning Activity -> Quiz/Assessment -> Learning Analytics
        -> Weak Spot Detection -> ML Model -> Recommendation Engine
        -> Personalized Recommendation -> Personalized Learning Path
        -> Student Learning -> New Activity Data -> Updated Recommendations
```

## Project layout

```
pathwise/
  backend/
    app/
      main.py               FastAPI app + router wiring
      config.py              Settings from environment
      database.py            SQLAlchemy engine/session
      models.py               ORM models (students, courses, lessons, quizzes,
                               attempts, topic_performance, recommendations...)
      schemas.py              Pydantic request/response models
      auth.py                 Password hashing + JWT
      seed_data.py             Course catalogue + demo student with activity
      ml/
        feature_extraction.py    Raw activity -> per-topic feature table
        weak_spot_detection.py   Classifies topics Strong/Average/Weak
        recommendation_engine.py Scores & ranks candidate resources
      routers/
        auth.py, dashboard.py, courses.py, lessons.py,
        assessments.py, recommendations.py, progress.py
    requirements.txt
    schema.sql                Reference SQL schema (for documentation)
    .env.example
  frontend/
    src/
      pages/                  Dashboard, MyLearning, Courses, CourseDetail,
                               Recommendations, Progress, Assessments, QuizTake,
                               Login, Signup
      components/              Sidebar, Topbar, Layout, RecommendationCard, ui.jsx
      context/AuthContext.jsx  JWT-backed auth state
      api/client.js             Axios instance with token attach + 401 handling
    tailwind.config.js         PathWise color tokens (navy/teal/purple/orange)
    .env.example
```

## 1. Database setup (MySQL)

```sql
CREATE DATABASE pathwise CHARACTER SET utf8mb4;
CREATE USER 'pathwise_user'@'localhost' IDENTIFIED BY 'pathwise_pass';
GRANT ALL PRIVILEGES ON pathwise.* TO 'pathwise_user'@'localhost';
FLUSH PRIVILEGES;
```

The app creates all tables automatically on first run via SQLAlchemy
(`Base.metadata.create_all`) - `schema.sql` is provided purely as a readable
reference of the same schema. Requires MySQL 8.0+ (for native `JSON` columns).

## 2. Backend setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env     # edit DATABASE_URL / SECRET_KEY as needed

# Run the API - the course catalogue is seeded automatically on startup,
# so real students always have courses to browse and enroll in with no
# manual step required
uvicorn app.main:app --reload --port 8000

# Optional: also create a demo account with pre-existing quiz history, so
# you can see weak-spot detection and recommendations working immediately
# without enrolling/completing anything yourself
python -m app.seed_data
```

API docs (Swagger UI) are then available at `http://localhost:8000/docs`.

If you ran the optional seed script, demo login: **demo@pathwise.app /
password123** - this account already has quiz history where "Loops" is
deliberately weak, matching the worked example in the project brief. A
freshly signed-up account starts with zero activity by design - browse
Courses, enroll, complete lessons and take quizzes to see Progress,
Assessments, and Recommendations populate from your own data.

## 3. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env      # VITE_API_URL should point at the backend
npm run dev
```

Open `http://localhost:5173`.

## How the ML pipeline fits together

1. **Activity capture** - every lesson open, time-on-task, and quiz
   submission is written to `lesson_progress` / `quiz_attempts` immediately
   (`routers/lessons.py`, `routers/assessments.py`).
2. **Feature extraction** (`ml/feature_extraction.py`) - turns that raw
   activity into one row per topic per student: average score, attempts,
   time spent, completion rate, and a recency-weighted score trend (via a
   simple linear fit over attempt order).
3. **Weak-spot detection** (`ml/weak_spot_detection.py`) - classifies each
   topic as Strong / Average / Weak from a confidence-adjusted score (low
   attempt counts are pulled toward neutral so one lucky/unlucky quiz can't
   flip a label), and persists it to `topic_performance` so the whole app
   reads the same numbers.
4. **Recommendation engine** (`ml/recommendation_engine.py`) - generates
   candidates per category (weak-area practice, continue-learning next
   lessons, challenge-yourself advanced material, and an overall top pick),
   scores each with `scikit-learn`'s `MinMaxScaler` over
   weakness/recency/momentum/difficulty-fit features, and folds in each
   student's own recommendation-feedback history as a small multiplier - so
   thumbs up/down actually change future rankings.
5. Every quiz submission re-runs steps 2-4, so recommendations update live
   as the brief requires, with no admin step anywhere in the loop.

## How the full loop connects (Courses -> My Learning -> Assessments -> Progress -> Recommendations -> Dashboard)

1. **Courses** - `GET /api/courses` lists the auto-seeded catalogue (search,
   subject and difficulty filters). Enrolling (`POST /api/courses/{id}/enroll`)
   creates an `Enrollment` row for that student.
2. **My Learning** (`GET /api/my-learning`) reads that student's
   `Enrollment` rows and splits them into in-progress vs completed, with
   live lesson-completion counts.
3. **Course learning page** - opening/completing a lesson
   (`POST /api/lessons/{id}/open` / `.../progress`) writes to
   `lesson_progress` and recalculates that course's `Enrollment.progress_percent`.
4. **Assessments** (`GET /api/assessments`) only lists quizzes belonging to
   courses the student is actually enrolled in - a student can't browse or
   submit a quiz for a course they haven't joined (enforced server-side,
   not just hidden in the UI). Submitting a quiz writes a `QuizAttempt` and
   immediately re-runs weak-spot detection + the recommendation engine.
5. **Progress** (`GET /api/progress`) aggregates every `QuizAttempt` and
   `LessonProgress` row for that student into the score-over-time chart,
   the topic performance table, and engagement analytics.
6. **Recommendations** (`GET /api/recommendations`) are generated from the
   student's own `TopicPerformance`, `Enrollment`, and `RecommendationFeedback`
   history - see the ML pipeline section above.
7. **Dashboard** (`GET /api/dashboard`) is a live aggregation across all of
   the above: summary cards, top recommendations, overall/subject progress,
   and learning insights all recompute from the same underlying tables, so
   it always reflects whatever happened on the other five pages.

A brand-new student therefore starts at all zeros by design - the loop
above is what fills every number in as they browse, enroll, learn, and take
quizzes.

## Notes on scope

- Difficulty/subject filters, sequential lesson unlocking, and streaks are
  all computed from real activity rows rather than hard-coded.
- The seed script uses a small hand-built course catalogue so the app is
  usable end-to-end out of the box; swapping in a public dataset (e.g. the
  OULAD or Kaggle "Student Performance and Learning Style" dataset) means
  writing an import script that populates `courses` / `lessons` / `quizzes`
  / `quiz_attempts` in the same shape - the ML pipeline itself doesn't need
  to change, since it already reads from those tables.
- There is intentionally no admin role, calendar, or settings page, per the
  brief.

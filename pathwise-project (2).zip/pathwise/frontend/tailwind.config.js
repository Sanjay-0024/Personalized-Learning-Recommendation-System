/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: "#102a56",
          50: "#eef2f9",
          100: "#d6e0f0",
          400: "#3a5a92",
          600: "#1a3a70",
          700: "#102a56",
          800: "#0b1e3f",
        },
        teal: {
          DEFAULT: "#14b8a6",
          50: "#e7faf8",
          100: "#c3f1ec",
          500: "#14b8a6",
          600: "#0f9689",
        },
        purple: {
          DEFAULT: "#7c5cf0",
          50: "#f1edfe",
          100: "#e1d8fd",
          500: "#7c5cf0",
          600: "#6642e0",
        },
        highlight: {
          DEFAULT: "#f7943c",
          50: "#fef3e7",
          500: "#f7943c",
          600: "#e57d22",
        },
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        card: "0 1px 2px 0 rgba(16, 42, 86, 0.06), 0 1px 6px 0 rgba(16, 42, 86, 0.05)",
      },
    },
  },
  plugins: [],
}

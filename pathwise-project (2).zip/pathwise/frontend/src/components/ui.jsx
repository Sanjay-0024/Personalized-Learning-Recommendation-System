export function ProgressBar({ label, percent, color = 'teal' }) {
  const colorMap = {
    teal: 'bg-teal-500',
    purple: 'bg-purple-500',
    navy: 'bg-navy-600',
    highlight: 'bg-highlight-500',
  }
  return (
    <div>
      <div className="flex justify-between text-sm mb-1.5">
        <span className="font-medium text-navy-700">{label}</span>
        <span className="text-navy-400">{Math.round(percent)}%</span>
      </div>
      <div className="h-2.5 w-full bg-navy-50 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full ${colorMap[color] || colorMap.teal}`}
          style={{ width: `${Math.min(100, Math.max(0, percent))}%` }}
        />
      </div>
    </div>
  )
}

export function CircularProgress({ percent, size = 160, stroke = 14 }) {
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (percent / 100) * circumference

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size / 2} cy={size / 2} r={radius} stroke="#eef2f9" strokeWidth={stroke} fill="none" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        stroke="#f7943c"
        strokeWidth={stroke}
        fill="none"
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: 'stroke-dashoffset 0.6s ease' }}
      />
      <text x="50%" y="50%" textAnchor="middle" dy="0.35em" fontSize={size * 0.2} fontWeight="700" fill="#102a56">
        {Math.round(percent)}%
      </text>
    </svg>
  )
}

const DIFFICULTY_COLORS = {
  Beginner: 'bg-teal-50 text-teal-600',
  Intermediate: 'bg-purple-50 text-purple-600',
  Advanced: 'bg-highlight-50 text-highlight-600',
}

export function DifficultyPill({ difficulty }) {
  return (
    <span className={`pill ${DIFFICULTY_COLORS[difficulty] || 'bg-navy-50 text-navy-600'}`}>{difficulty}</span>
  )
}

export function MatchBadge({ percent }) {
  return (
    <span className="pill bg-navy-700 text-white font-semibold">{Math.round(percent)}% Match</span>
  )
}

export function StatusPill({ status }) {
  const map = {
    Strong: 'bg-teal-50 text-teal-600',
    Average: 'bg-purple-50 text-purple-600',
    Weak: 'bg-highlight-50 text-highlight-600',
  }
  return <span className={`pill ${map[status] || 'bg-navy-50 text-navy-600'}`}>{status}</span>
}

import { useState } from 'react'
import { DifficultyPill, MatchBadge } from './ui'
import client from '../api/client'

export default function RecommendationCard({ rec, onStart, showFeedback = false }) {
  const [feedbackGiven, setFeedbackGiven] = useState(null)

  const sendFeedback = async (helpful) => {
    try {
      await client.post(`/api/recommendations/${rec.id}/feedback`, { helpful })
      setFeedbackGiven(helpful ? 'up' : 'down')
    } catch (e) {
      // non-critical UI feedback call - fail quietly
    }
  }

  return (
    <div className="card flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="font-semibold text-navy-700">{rec.title}</h3>
          <p className="text-xs text-navy-400 mt-0.5">{rec.subject} • {rec.topic}</p>
        </div>
        <MatchBadge percent={rec.match_percent} />
      </div>

      <div className="flex items-center gap-2">
        <DifficultyPill difficulty={rec.difficulty} />
        <span className="pill bg-navy-50 text-navy-600">{rec.resource_type}</span>
      </div>

      <p className="text-sm text-navy-400 leading-relaxed">{rec.reason}</p>

      <div className="flex items-center justify-between mt-1">
        <button onClick={() => onStart?.(rec)} className="btn-teal text-sm">
          Start Learning
        </button>

        {showFeedback && (
          <div className="flex items-center gap-2 text-sm">
            <button
              onClick={() => sendFeedback(true)}
              className={`px-2 py-1 rounded-lg ${feedbackGiven === 'up' ? 'bg-teal-50' : 'hover:bg-navy-50'}`}
              aria-label="Helpful"
            >
              👍
            </button>
            <button
              onClick={() => sendFeedback(false)}
              className={`px-2 py-1 rounded-lg ${feedbackGiven === 'down' ? 'bg-highlight-50' : 'hover:bg-navy-50'}`}
              aria-label="Not helpful"
            >
              👎
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

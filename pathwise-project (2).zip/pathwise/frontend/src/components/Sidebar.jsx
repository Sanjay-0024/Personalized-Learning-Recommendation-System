import { NavLink } from 'react-router-dom'

const NAV_ITEMS = [
  { to: '/dashboard', label: 'Dashboard', icon: '🏠' },
  { to: '/my-learning', label: 'My Learning', icon: '📚' },
  { to: '/recommendations', label: 'Recommendations', icon: '🤖' },
  { to: '/courses', label: 'Courses', icon: '📖' },
  { to: '/progress', label: 'Progress', icon: '📊' },
  { to: '/assessments', label: 'Assessments', icon: '📝' },
]

export default function Sidebar() {
  return (
    <aside className="hidden md:flex flex-col w-64 shrink-0 bg-navy-700 text-white min-h-screen px-4 py-6">
      <div className="flex items-center gap-2 px-2 mb-8">
        <div className="w-9 h-9 rounded-xl bg-teal-500 flex items-center justify-center font-bold text-navy-800">P</div>
        <span className="text-lg font-semibold tracking-tight">PathWise</span>
      </div>

      <nav className="flex-1 space-y-1">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive ? 'bg-white/10 text-white' : 'text-navy-100 hover:bg-white/5'
              }`
            }
          >
            <span aria-hidden>{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="px-3 py-4 rounded-xl bg-white/5 text-xs text-navy-100">
        Powered by PathWise's ML recommendation engine - your path adapts as you learn.
      </div>
    </aside>
  )
}

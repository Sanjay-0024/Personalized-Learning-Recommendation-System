import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Topbar() {
  const { student, logout } = useAuth()
  const [menuOpen, setMenuOpen] = useState(false)

  const initials = student?.full_name
    ?.split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  return (
    <header className="flex items-center justify-between gap-4 px-6 py-4 bg-white border-b border-navy-50">
      <div className="flex-1 max-w-md">
        <input
          type="search"
          placeholder="Search courses, topics, lessons..."
          className="w-full rounded-xl border border-navy-50 bg-navy-50/40 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
        />
      </div>

      <div className="flex items-center gap-4">
        <button className="relative w-9 h-9 rounded-full bg-navy-50 flex items-center justify-center hover:bg-navy-100 transition-colors" aria-label="Notifications">
          🔔
          <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-highlight-500 border-2 border-white" />
        </button>

        <div className="relative">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="flex items-center gap-2"
          >
            <div className="w-9 h-9 rounded-full bg-purple-500 text-white flex items-center justify-center text-sm font-semibold">
              {initials || 'S'}
            </div>
            <span className="hidden sm:block text-sm font-medium text-navy-700">{student?.full_name}</span>
          </button>
          {menuOpen && (
            <div className="absolute right-0 mt-2 w-40 bg-white rounded-xl shadow-card border border-navy-50 py-1 z-10">
              <button
                onClick={logout}
                className="w-full text-left px-4 py-2 text-sm text-navy-700 hover:bg-navy-50 rounded-xl"
              >
                Log out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}

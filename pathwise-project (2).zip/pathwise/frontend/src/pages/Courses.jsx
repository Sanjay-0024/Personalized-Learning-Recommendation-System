import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'
import { DifficultyPill } from '../components/ui'
import client from '../api/client'

const DIFFICULTIES = ['Beginner', 'Intermediate', 'Advanced']

export default function Courses() {
  const [courses, setCourses] = useState([])
  const [enrolledIds, setEnrolledIds] = useState(new Set())
  const [search, setSearch] = useState('')
  const [difficulty, setDifficulty] = useState('')
  const [subject, setSubject] = useState('')
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  const fetchCourses = () => {
    setLoading(true)
    client
      .get('/api/courses', { params: { search: search || undefined, difficulty: difficulty || undefined, subject: subject || undefined } })
      .then((res) => setCourses(res.data))
      .finally(() => setLoading(false))
  }

  const fetchEnrolled = () => {
    client.get('/api/my-learning').then((res) => {
      const ids = [...res.data.currently_learning, ...res.data.completed_courses].map((c) => c.course_id)
      setEnrolledIds(new Set(ids))
    })
  }

  useEffect(() => {
    fetchCourses()
    fetchEnrolled()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const subjects = [...new Set(courses.map((c) => c.subject))]

  const enroll = async (courseId) => {
    if (enrolledIds.has(courseId)) {
      navigate(`/courses/${courseId}`)
      return
    }
    await client.post(`/api/courses/${courseId}/enroll`)
    navigate(`/courses/${courseId}`)
  }

  return (
    <Layout>
      <h1 className="text-xl font-semibold text-navy-700 mb-6">Courses</h1>

      <div className="card mb-6 flex flex-col md:flex-row gap-3">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && fetchCourses()}
          placeholder="Search courses..."
          className="flex-1 rounded-xl border border-navy-50 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
        />
        <select value={difficulty} onChange={(e) => setDifficulty(e.target.value)} className="rounded-xl border border-navy-50 px-3 py-2 text-sm">
          <option value="">All difficulties</option>
          {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select value={subject} onChange={(e) => setSubject(e.target.value)} className="rounded-xl border border-navy-50 px-3 py-2 text-sm">
          <option value="">All subjects</option>
          {subjects.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <button onClick={fetchCourses} className="btn-primary text-sm">Search</button>
      </div>

      {loading ? (
        <p className="text-navy-400">Loading courses...</p>
      ) : courses.length === 0 ? (
        <div className="card text-center py-12 text-navy-400">
          No courses match your filters right now - try clearing search or filters.
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map((course) => (
            <div key={course.id} className="card flex flex-col gap-3">
              <div>
                <h3 className="font-semibold text-navy-700">{course.title}</h3>
                <p className="text-xs text-navy-400 mt-0.5">{course.subject} • {course.category}</p>
              </div>
              <p className="text-sm text-navy-400 leading-relaxed line-clamp-3">{course.description}</p>
              <div className="flex items-center gap-2">
                <DifficultyPill difficulty={course.difficulty} />
                <span className="pill bg-navy-50 text-navy-600">{course.num_lessons} lessons</span>
                <span className="pill bg-navy-50 text-navy-600">{course.estimated_hours}h</span>
              </div>
              <div className="flex items-center justify-between mt-1">
                <span className="text-sm text-highlight-600 font-medium">★ {course.rating}</span>
                <button onClick={() => enroll(course.id)} className={enrolledIds.has(course.id) ? 'btn-outline text-sm' : 'btn-teal text-sm'}>
                  {enrolledIds.has(course.id) ? 'Continue Learning' : 'Enroll / Start'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Layout>
  )
}

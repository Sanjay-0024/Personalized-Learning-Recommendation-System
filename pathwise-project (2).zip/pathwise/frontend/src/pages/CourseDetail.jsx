import { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import Layout from '../components/Layout'
import { DifficultyPill, ProgressBar } from '../components/ui'
import client from '../api/client'

const RESOURCE_ICON = { Video: '🎬', Reading: '📖', Practice: '🧩', Quiz: '📝', Example: '💡' }

export default function CourseDetail() {
  const { courseId } = useParams()
  const [course, setCourse] = useState(null)
  const [activeLesson, setActiveLesson] = useState(null)
  const [loading, setLoading] = useState(true)
  const secondsRef = useRef(0)

  const loadCourse = () => {
    client.get(`/api/courses/${courseId}`).then((res) => {
      setCourse(res.data)
      const firstIncomplete = res.data.lessons.find((l) => !l.completed) || res.data.lessons[0]
      setActiveLesson((prev) => prev || firstIncomplete)
    }).finally(() => setLoading(false))
  }

  useEffect(() => { loadCourse() }, [courseId]) // eslint-disable-line react-hooks/exhaustive-deps

  // Track time spent on the open lesson in 15s increments
  useEffect(() => {
    if (!activeLesson) return
    client.post(`/api/lessons/${activeLesson.id}/open`)
    secondsRef.current = 0
    const interval = setInterval(() => {
      secondsRef.current += 15
      client.post(`/api/lessons/${activeLesson.id}/progress`, { time_spent_seconds: 15, completed: false })
    }, 15000)
    return () => clearInterval(interval)
  }, [activeLesson?.id]) // eslint-disable-line react-hooks/exhaustive-deps

  const markComplete = async () => {
    await client.post(`/api/lessons/${activeLesson.id}/progress`, { time_spent_seconds: 0, completed: true })
    loadCourse()
  }

  if (loading) return <Layout><p className="text-navy-400">Loading course...</p></Layout>
  if (!course) return <Layout><p className="text-navy-400">Course not found.</p></Layout>

  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-navy-700">{course.title}</h1>
        <p className="text-sm text-navy-400 mt-1 max-w-2xl">{course.description}</p>
        <div className="mt-3 max-w-sm">
          <ProgressBar label="Course progress" percent={course.progress_percent} />
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="card md:col-span-1 h-fit">
          <h2 className="text-sm font-semibold text-navy-700 mb-3">Lessons</h2>
          <div className="space-y-1">
            {course.lessons.map((lesson) => (
              <button
                key={lesson.id}
                onClick={() => !lesson.locked && setActiveLesson(lesson)}
                disabled={lesson.locked}
                className={`w-full text-left px-3 py-2.5 rounded-xl text-sm flex items-center gap-2 transition-colors ${
                  activeLesson?.id === lesson.id ? 'bg-navy-700 text-white' : lesson.locked ? 'text-navy-400 cursor-not-allowed' : 'hover:bg-navy-50 text-navy-700'
                }`}
              >
                <span>{lesson.locked ? '🔒' : lesson.completed ? '✅' : RESOURCE_ICON[lesson.resource_type] || '📄'}</span>
                <span className="flex-1">{lesson.title}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="card md:col-span-2">
          {activeLesson ? (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <DifficultyPill difficulty={activeLesson.difficulty} />
                <span className="pill bg-navy-50 text-navy-600">{activeLesson.resource_type}</span>
                <span className="pill bg-navy-50 text-navy-600">{activeLesson.estimated_minutes} min</span>
              </div>
              <h2 className="text-lg font-semibold text-navy-700">{activeLesson.title}</h2>
              <p className="text-xs text-navy-400 mb-4">Topic: {activeLesson.topic}</p>

              <div className="bg-navy-50/60 rounded-xl p-6 text-navy-700 text-sm leading-relaxed mb-6">
                {activeLesson.content_notes}
              </div>

              <div className="flex items-center gap-3">
                <button onClick={markComplete} disabled={activeLesson.completed} className="btn-teal text-sm disabled:opacity-50">
                  {activeLesson.completed ? 'Completed' : 'Mark as Complete'}
                </button>
              </div>
            </div>
          ) : (
            <p className="text-navy-400">Select a lesson to begin.</p>
          )}
        </div>
      </div>
    </Layout>
  )
}

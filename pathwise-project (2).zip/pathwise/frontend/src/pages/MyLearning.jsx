import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'
import { ProgressBar } from '../components/ui'
import client from '../api/client'

export default function MyLearning() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    client.get('/api/my-learning').then((res) => setData(res.data)).finally(() => setLoading(false))
  }, [])

  if (loading) return <Layout><p className="text-navy-400">Loading your courses...</p></Layout>

  const { currently_learning = [], completed_courses = [] } = data || {}

  return (
    <Layout>
      <h1 className="text-xl font-semibold text-navy-700 mb-6">My Learning</h1>

      <section className="mb-8">
        <h2 className="text-lg font-semibold text-navy-700 mb-4">Currently Learning</h2>
        {currently_learning.length === 0 ? (
          <EmptyState text="You haven't started a course yet." cta="Browse courses" onClick={() => navigate('/courses')} />
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {currently_learning.map((c) => (
              <div key={c.course_id} className="card">
                <h3 className="font-semibold text-navy-700">{c.title}</h3>
                <p className="text-xs text-navy-400 mb-3">{c.subject} • Last accessed {new Date(c.last_accessed).toLocaleDateString()}</p>
                <ProgressBar label={`${c.completed_lessons} / ${c.total_lessons} lessons`} percent={c.progress_percent} />
                <button onClick={() => navigate(`/courses/${c.course_id}`)} className="btn-teal text-sm mt-4">
                  Continue Learning
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="text-lg font-semibold text-navy-700 mb-4">Completed Courses</h2>
        {completed_courses.length === 0 ? (
          <EmptyState text="No completed courses yet - finish a course to see it here." />
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {completed_courses.map((c) => (
              <div key={c.course_id} className="card">
                <h3 className="font-semibold text-navy-700">{c.title}</h3>
                <p className="text-xs text-navy-400 mt-1">{c.subject}</p>
                <div className="flex justify-between text-sm mt-3">
                  <span className="text-navy-400">Final score</span>
                  <span className="font-semibold text-teal-600">{c.final_score ?? '—'}%</span>
                </div>
                <div className="flex justify-between text-sm mt-1">
                  <span className="text-navy-400">Completed</span>
                  <span className="font-medium text-navy-700">{c.completed_at ? new Date(c.completed_at).toLocaleDateString() : '—'}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </Layout>
  )
}

function EmptyState({ text, cta, onClick }) {
  return (
    <div className="card text-center py-10">
      <p className="text-navy-400 mb-3">{text}</p>
      {cta && <button onClick={onClick} className="btn-primary text-sm">{cta}</button>}
    </div>
  )
}

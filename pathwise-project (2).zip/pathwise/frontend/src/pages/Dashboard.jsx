import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'
import RecommendationCard from '../components/RecommendationCard'
import { CircularProgress, ProgressBar } from '../components/ui'
import client from '../api/client'
import { useAuth } from '../context/AuthContext'

const SUBJECT_COLORS = ['teal', 'purple', 'navy', 'highlight', 'teal']

export default function Dashboard() {
  const { student } = useAuth()
  const navigate = useNavigate()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    client.get('/api/dashboard').then((res) => setData(res.data)).finally(() => setLoading(false))
  }, [])

  const startRecommendation = (rec) => {
    if (rec.course_id) navigate(`/courses/${rec.course_id}`)
  }

  if (loading) return <Layout><p className="text-navy-400">Loading your dashboard...</p></Layout>
  if (!data) return <Layout><p className="text-navy-400">Couldn't load your dashboard right now.</p></Layout>

  const { summary, recommendations, overall_progress, subject_progress, insights } = data

  return (
    <Layout>
      <section className="card bg-gradient-to-br from-navy-700 to-navy-600 text-white mb-6">
        <h1 className="text-2xl font-semibold">Welcome back, {student?.full_name?.split(' ')[0]}!</h1>
        <p className="text-navy-100 mt-1">Small consistent sessions compound - keep your streak going.</p>
        <p className="text-sm text-teal-100 mt-3">🎯 Goal: {data.learning_goal}</p>
        <button onClick={() => navigate('/my-learning')} className="mt-4 bg-teal-500 hover:bg-teal-600 transition-colors text-white font-medium rounded-xl px-4 py-2 text-sm">
          Continue Learning
        </button>
      </section>

      <section className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <SummaryCard label="Learning Streak" value={`${summary.learning_streak_days} Days`} color="highlight" icon="🔥" />
        <SummaryCard label="Courses in Progress" value={`${summary.courses_in_progress} Courses`} color="teal" icon="📚" />
        <SummaryCard label="Completed Lessons" value={`${summary.completed_lessons} Lessons`} color="purple" icon="✅" />
        <SummaryCard label="Average Score" value={`${summary.average_score}%`} color="navy" icon="⭐" />
      </section>

      <section className="mb-6">
        <div className="flex items-baseline justify-between mb-1">
          <h2 className="text-lg font-semibold text-navy-700">AI Recommended For You</h2>
        </div>
        <p className="text-sm text-navy-400 mb-4">Personalized recommendations based on your learning performance and progress.</p>
        {recommendations.length === 0 ? (
          <p className="text-sm text-navy-400 card">Complete a lesson or quiz to unlock personalized recommendations.</p>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {recommendations.map((rec) => (
              <RecommendationCard key={rec.id} rec={rec} onStart={startRecommendation} />
            ))}
          </div>
        )}
      </section>

      <section className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="card">
          <h2 className="text-lg font-semibold text-navy-700 mb-4">Overall Learning Progress</h2>
          <div className="flex items-center gap-6">
            <CircularProgress percent={overall_progress.overall_percent} />
            <div className="space-y-2 text-sm">
              <Stat label="Lessons completed" value={overall_progress.lessons_completed} />
              <Stat label="Lessons remaining" value={overall_progress.lessons_remaining} />
              <Stat label="Courses completed" value={overall_progress.courses_completed} />
              <Stat label="Active courses" value={overall_progress.active_courses} />
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold text-navy-700 mb-4">Subject-Wise Progress</h2>
          <div className="space-y-4">
            {subject_progress.length === 0 && <p className="text-sm text-navy-400">Enroll in a course to see subject progress here.</p>}
            {subject_progress.map((s, i) => (
              <ProgressBar key={s.subject} label={s.subject} percent={s.progress_percent} color={SUBJECT_COLORS[i % SUBJECT_COLORS.length]} />
            ))}
          </div>
        </div>
      </section>

      <section className="card">
        <h2 className="text-lg font-semibold text-navy-700 mb-4">Learning Insights</h2>
        <div className="grid sm:grid-cols-2 gap-6">
          <InsightBlock title="Strong Areas" items={insights.strong_areas} pillStatus="Strong" empty="Keep going - strong areas will show up here." />
          <InsightBlock title="Needs Improvement" items={insights.needs_improvement} pillStatus="Weak" empty="No weak areas detected yet." />
          <InsightBlock title="Recently Learned" items={insights.recently_learned} empty="Complete a lesson to see it here." />
          <div>
            <h3 className="text-sm font-semibold text-navy-700 mb-2">Recommended Next Step</h3>
            <p className="text-sm text-navy-400">{insights.recommended_next_step || 'Take a quiz to get a personalized next step.'}</p>
          </div>
        </div>
      </section>
    </Layout>
  )
}

function SummaryCard({ label, value, icon, color }) {
  const bg = { highlight: 'bg-highlight-50', teal: 'bg-teal-50', purple: 'bg-purple-50', navy: 'bg-navy-50' }[color]
  return (
    <div className="card">
      <div className={`w-9 h-9 rounded-lg ${bg} flex items-center justify-center text-lg mb-3`}>{icon}</div>
      <p className="text-xs text-navy-400">{label}</p>
      <p className="text-xl font-semibold text-navy-700 mt-0.5">{value}</p>
    </div>
  )
}

function Stat({ label, value }) {
  return (
    <div className="flex justify-between gap-6">
      <span className="text-navy-400">{label}</span>
      <span className="font-semibold text-navy-700">{value}</span>
    </div>
  )
}

const STATUS_TONE = {
  Strong: 'bg-teal-50 text-teal-600',
  Weak: 'bg-highlight-50 text-highlight-600',
}

function InsightBlock({ title, items, pillStatus, empty }) {
  return (
    <div>
      <h3 className="text-sm font-semibold text-navy-700 mb-2">{title}</h3>
      {items.length === 0 ? (
        <p className="text-sm text-navy-400">{empty}</p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {items.map((item) => (
            <span key={item} className={`pill ${pillStatus ? STATUS_TONE[pillStatus] : 'bg-navy-50 text-navy-600'}`}>
              {item}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

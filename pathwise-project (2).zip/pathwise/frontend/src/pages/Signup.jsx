import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Signup() {
  const { signup } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ fullName: '', email: '', password: '', confirmPassword: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match.')
      return
    }
    setLoading(true)
    try {
      await signup(form.fullName, form.email, form.password, form.confirmPassword)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.detail || 'Could not create your account. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-navy-700 px-4 py-10">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2 justify-center mb-8">
          <div className="w-10 h-10 rounded-xl bg-teal-500 flex items-center justify-center font-bold text-navy-800">P</div>
          <span className="text-2xl font-semibold text-white tracking-tight">PathWise</span>
        </div>

        <div className="bg-white rounded-2xl shadow-card p-8">
          <h1 className="text-xl font-semibold text-navy-700 mb-1">Create your account</h1>
          <p className="text-sm text-navy-400 mb-6">Start a learning path built around your own performance.</p>

          {error && <div className="mb-4 text-sm text-highlight-600 bg-highlight-50 rounded-lg px-3 py-2">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-navy-700 mb-1">Full Name</label>
              <input required value={form.fullName} onChange={update('fullName')}
                className="w-full rounded-xl border border-navy-50 px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
                placeholder="Jordan Lee" />
            </div>
            <div>
              <label className="block text-sm font-medium text-navy-700 mb-1">Email</label>
              <input type="email" required value={form.email} onChange={update('email')}
                className="w-full rounded-xl border border-navy-50 px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
                placeholder="you@example.com" />
            </div>
            <div>
              <label className="block text-sm font-medium text-navy-700 mb-1">Password</label>
              <input type="password" required minLength={6} value={form.password} onChange={update('password')}
                className="w-full rounded-xl border border-navy-50 px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
                placeholder="At least 6 characters" />
            </div>
            <div>
              <label className="block text-sm font-medium text-navy-700 mb-1">Confirm Password</label>
              <input type="password" required value={form.confirmPassword} onChange={update('confirmPassword')}
                className="w-full rounded-xl border border-navy-50 px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
                placeholder="Re-enter your password" />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center flex">
              {loading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>

          <p className="text-sm text-navy-400 text-center mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-teal-600 font-medium">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}

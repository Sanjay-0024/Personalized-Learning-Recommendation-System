import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Layout from '../components/Layout'
import { DifficultyPill } from '../components/ui'
import client from '../api/client'

export default function Assessments() {
  const [quizzes, setQuizzes] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    client.get('/api/assessments').then((res) => setQuizzes(res.data)).finally(() => setLoading(false))
  }, [])

  if (loading) return <Layout><p className="text-navy-400">Loading assessments...</p></Layout>

  return (
    <Layout>
      <h1 className="text-xl font-semibold text-navy-700 mb-6">Assessments</h1>

      {quizzes.length === 0 ? (
        <div className="card text-center py-12 text-navy-400">
          Enroll in a course to unlock its quizzes here.
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {quizzes.map((quiz) => (
            <div key={quiz.id} className="card flex flex-col gap-3">
              <div>
                <h3 className="font-semibold text-navy-700">{quiz.title}</h3>
                <p className="text-xs text-navy-400 mt-0.5">{quiz.course_title} • {quiz.topic}</p>
              </div>
              <div className="flex items-center gap-2">
                <DifficultyPill difficulty={quiz.difficulty} />
                <span className="pill bg-navy-50 text-navy-600">{quiz.num_questions} questions</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-navy-400">
                  {quiz.attempt_count > 0 ? `${quiz.attempt_count} previous attempt(s)` : 'Not attempted yet'}
                </span>
                {quiz.best_score != null && (
                  <span className="font-semibold text-teal-600">Best: {Math.round(quiz.best_score)}%</span>
                )}
              </div>
              <button onClick={() => navigate(`/assessments/${quiz.id}`)} className="btn-primary text-sm">
                {quiz.attempt_count > 0 ? 'Retake Quiz' : 'Start Quiz'}
              </button>
            </div>
          ))}
        </div>
      )}
    </Layout>
  )
}

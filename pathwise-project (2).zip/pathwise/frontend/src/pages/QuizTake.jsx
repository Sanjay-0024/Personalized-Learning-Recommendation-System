import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import Layout from '../components/Layout'
import client from '../api/client'

export default function QuizTake() {
  const { quizId } = useParams()
  const navigate = useNavigate()
  const [quiz, setQuiz] = useState(null)
  const [loadError, setLoadError] = useState('')
  const [current, setCurrent] = useState(0)
  const [answers, setAnswers] = useState({})
  const [result, setResult] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [startedAt] = useState(Date.now())

  useEffect(() => {
    client.get(`/api/assessments/${quizId}`)
      .then((res) => setQuiz(res.data))
      .catch((err) => setLoadError(err.response?.data?.detail || 'Could not load this quiz.'))
  }, [quizId])

  if (loadError) {
    return (
      <Layout>
        <div className="max-w-lg mx-auto card text-center">
          <p className="text-navy-400 mb-4">{loadError}</p>
          <button onClick={() => navigate('/assessments')} className="btn-primary text-sm">Back to Assessments</button>
        </div>
      </Layout>
    )
  }

  if (!quiz) return <Layout><p className="text-navy-400">Loading quiz...</p></Layout>

  if (result) {
    return (
      <Layout>
        <div className="max-w-lg mx-auto card text-center">
          <p className="text-sm text-navy-400">Your Score</p>
          <p className="text-5xl font-bold text-navy-700 my-3">{Math.round(result.score_percent)}%</p>
          <div className="flex justify-center gap-6 text-sm mb-4">
            <span className="text-teal-600 font-medium">{result.correct_count} correct</span>
            <span className="text-highlight-600 font-medium">{result.incorrect_count} incorrect</span>
          </div>
          <div className="bg-navy-50/60 rounded-xl p-4 text-sm text-navy-700 text-left mb-6">
            <p className="font-medium mb-1">AI Recommendation</p>
            <p>{result.recommended_next_action}</p>
          </div>
          <div className="flex gap-3 justify-center">
            <button onClick={() => navigate('/recommendations')} className="btn-teal text-sm">See Recommendations</button>
            <button onClick={() => navigate('/assessments')} className="btn-outline text-sm">Back to Assessments</button>
          </div>
        </div>
      </Layout>
    )
  }

  const question = quiz.questions[current]
  const total = quiz.questions.length
  const answeredCount = Object.keys(answers).length

  const selectAnswer = (index) => {
    setAnswers((a) => ({ ...a, [question.id]: index }))
  }

  const submit = async () => {
    setSubmitting(true)
    const payload = {
      answers: Object.entries(answers).map(([question_id, selected_index]) => ({
        question_id: Number(question_id),
        selected_index,
      })),
      time_spent_seconds: Math.round((Date.now() - startedAt) / 1000),
    }
    try {
      const { data } = await client.post(`/api/assessments/${quizId}/submit`, payload)
      setResult(data)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-lg font-semibold text-navy-700">{quiz.title}</h1>
          <span className="text-sm text-navy-400">Question {current + 1} of {total}</span>
        </div>

        <div className="h-2 w-full bg-navy-50 rounded-full overflow-hidden mb-6">
          <div className="h-full bg-teal-500 rounded-full transition-all" style={{ width: `${((current + 1) / total) * 100}%` }} />
        </div>

        <div className="card mb-6">
          <p className="font-medium text-navy-700 mb-4">{question.text}</p>
          <div className="space-y-2">
            {question.options.map((opt, idx) => (
              <button
                key={idx}
                onClick={() => selectAnswer(idx)}
                className={`w-full text-left px-4 py-3 rounded-xl border text-sm transition-colors ${
                  answers[question.id] === idx
                    ? 'border-teal-500 bg-teal-50 text-teal-700 font-medium'
                    : 'border-navy-50 hover:bg-navy-50 text-navy-700'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between">
          <button
            onClick={() => setCurrent((c) => Math.max(0, c - 1))}
            disabled={current === 0}
            className="btn-outline text-sm disabled:opacity-40"
          >
            Previous
          </button>

          <div className="flex gap-1">
            {quiz.questions.map((q, idx) => (
              <button
                key={q.id}
                onClick={() => setCurrent(idx)}
                className={`w-7 h-7 rounded-lg text-xs font-medium ${
                  idx === current ? 'bg-navy-700 text-white' : answers[q.id] !== undefined ? 'bg-teal-50 text-teal-600' : 'bg-navy-50 text-navy-400'
                }`}
              >
                {idx + 1}
              </button>
            ))}
          </div>

          {current < total - 1 ? (
            <button onClick={() => setCurrent((c) => Math.min(total - 1, c + 1))} className="btn-outline text-sm">
              Next
            </button>
          ) : (
            <button
              onClick={submit}
              disabled={submitting || answeredCount < total}
              className="btn-primary text-sm disabled:opacity-40"
            >
              {submitting ? 'Submitting...' : 'Submit'}
            </button>
          )}
        </div>
      </div>
    </Layout>
  )
}

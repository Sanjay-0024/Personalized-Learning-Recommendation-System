import { useEffect, useState } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import Layout from '../components/Layout'
import { StatusPill } from '../components/ui'
import client from '../api/client'

export default function Progress() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    client.get('/api/progress').then((res) => setData(res.data)).finally(() => setLoading(false))
  }, [])

  if (loading) return <Layout><p className="text-navy-400">Crunching your analytics...</p></Layout>
  if (!data) return <Layout><p className="text-navy-400">No analytics available yet.</p></Layout>

  const chartData = data.score_history.map((p) => ({
    date: new Date(p.attempted_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
    score: p.score_percent,
  }))

  return (
    <Layout>
      <h1 className="text-xl font-semibold text-navy-700 mb-6">Learning Progress</h1>

      <section className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Metric label="Average Score" value={`${data.average_score}%`} />
        <Metric label="Course Completion" value={`${data.overall_completion_percent}%`} />
        <Metric label="Learning Time" value={`${data.total_learning_time_minutes} min`} />
        <Metric label="Quiz Attempts" value={data.quiz_attempts} />
      </section>

      <section className="card mb-6">
        <h2 className="text-lg font-semibold text-navy-700 mb-4">Performance Over Time</h2>
        {chartData.length === 0 ? (
          <p className="text-sm text-navy-400">Take a few quizzes to see your score trend here.</p>
        ) : (
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef2f9" />
              <XAxis dataKey="date" tick={{ fontSize: 12, fill: '#3a5a92' }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: '#3a5a92' }} />
              <Tooltip />
              <Line type="monotone" dataKey="score" stroke="#14b8a6" strokeWidth={3} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </section>

      <section className="card mb-6">
        <h2 className="text-lg font-semibold text-navy-700 mb-4">Topic Performance</h2>
        {data.topics.length === 0 ? (
          <p className="text-sm text-navy-400">No topic data yet - attempt a quiz to populate this table.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-navy-400 border-b border-navy-50">
                  <th className="py-2 font-medium">Topic</th>
                  <th className="py-2 font-medium">Subject</th>
                  <th className="py-2 font-medium">Score</th>
                  <th className="py-2 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {data.topics.map((t) => (
                  <tr key={t.topic} className="border-b border-navy-50/60">
                    <td className="py-2.5 font-medium text-navy-700">{t.topic}</td>
                    <td className="py-2.5 text-navy-400">{t.subject}</td>
                    <td className="py-2.5 text-navy-700">{Math.round(t.avg_score)}%</td>
                    <td className="py-2.5"><StatusPill status={t.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="card">
        <h2 className="text-lg font-semibold text-navy-700 mb-4">Engagement Analytics</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
          <Metric label="Active days / week" value={data.engagement.learning_frequency_per_week} small />
          <Metric label="Time spent" value={`${data.engagement.total_time_spent_minutes} min`} small />
          <Metric label="Lessons completed" value={data.engagement.lessons_completed} small />
          <Metric label="Quiz attempts" value={data.engagement.quiz_attempts} small />
          <Metric label="Resources accessed" value={data.engagement.resources_accessed} small />
        </div>
      </section>
    </Layout>
  )
}

function Metric({ label, value, small }) {
  return (
    <div className={small ? 'card' : 'card'}>
      <p className="text-xs text-navy-400">{label}</p>
      <p className="text-lg font-semibold text-navy-700 mt-0.5">{value}</p>
    </div>
  )
}

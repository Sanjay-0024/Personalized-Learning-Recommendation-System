import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(email, password)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.detail || 'Could not log in. Check your details and try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-navy-700 px-4">
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2 justify-center mb-8">
          <div className="w-10 h-10 rounded-xl bg-teal-500 flex items-center justify-center font-bold text-navy-800">P</div>
          <span className="text-2xl font-semibold text-white tracking-tight">PathWise</span>
        </div>

        <div className="bg-white rounded-2xl shadow-card p-8">
          <h1 className="text-xl font-semibold text-navy-700 mb-1">Welcome back</h1>
          <p className="text-sm text-navy-400 mb-6">Log in to continue your personalized learning path.</p>

          {error && <div className="mb-4 text-sm text-highlight-600 bg-highlight-50 rounded-lg px-3 py-2">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-navy-700 mb-1">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-navy-50 px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-navy-700 mb-1">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-navy-50 px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-500"
                placeholder="••••••••"
              />
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center flex">
              {loading ? 'Logging in...' : 'Log In'}
            </button>
          </form>

          <p className="text-sm text-navy-400 text-center mt-6">
            New to PathWise?{' '}
            <Link to="/signup" className="text-teal-600 font-medium">Create an account</Link>
          </p>

          <p className="text-xs text-navy-400 text-center mt-4 bg-navy-50/60 rounded-lg py-2">
            Demo login: demo@pathwise.app / password123
          </p>
        </div>
      </div>
    </div>
  )
}

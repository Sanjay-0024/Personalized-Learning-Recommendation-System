import { createContext, useContext, useState } from 'react'
import client from '../api/client'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [student, setStudent] = useState(() => {
    const raw = localStorage.getItem('pathwise_student')
    return raw ? JSON.parse(raw) : null
  })

  const persist = (token, studentData) => {
    localStorage.setItem('pathwise_token', token)
    localStorage.setItem('pathwise_student', JSON.stringify(studentData))
    setStudent(studentData)
  }

  const login = async (email, password) => {
    const { data } = await client.post('/api/auth/login', { email, password })
    persist(data.access_token, data.student)
    return data.student
  }

  const signup = async (fullName, email, password, confirmPassword) => {
    const { data } = await client.post('/api/auth/signup', {
      full_name: fullName,
      email,
      password,
      confirm_password: confirmPassword,
    })
    persist(data.access_token, data.student)
    return data.student
  }

  const logout = () => {
    localStorage.removeItem('pathwise_token')
    localStorage.removeItem('pathwise_student')
    setStudent(null)
  }

  return (
    <AuthContext.Provider value={{ student, login, signup, logout, isAuthenticated: !!student }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}

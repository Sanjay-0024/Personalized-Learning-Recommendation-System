from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, SessionLocal
from app.config import settings
from app.routers import auth, dashboard, courses, lessons, assessments, recommendations, progress
from app.seed_data import seed_course_catalogue

Base.metadata.create_all(bind=engine)

# Guarantee the course catalogue exists on every startup - a brand new
# database should always have real courses for students to browse and
# enroll in, with no manual seeding step required. This is a no-op once
# courses already exist.
_db = SessionLocal()
try:
    seed_course_catalogue(_db)
finally:
    _db.close()

app = FastAPI(
    title="PathWise API",
    description="Personalized Learning Recommendation Engine - REST API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(dashboard.router)
app.include_router(courses.router)
app.include_router(lessons.router)
app.include_router(assessments.router)
app.include_router(recommendations.router)
app.include_router(progress.router)


@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "pathwise-api"}

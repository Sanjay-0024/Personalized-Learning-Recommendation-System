from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_student
from app.models import Course, Lesson, Enrollment, LessonProgress, Student
from app.schemas import CourseOut, CourseDetailOut, LessonOut, MyLearningCourse

router = APIRouter(prefix="/api", tags=["courses"])


@router.get("/courses", response_model=List[CourseOut])
def browse_courses(
    search: Optional[str] = None,
    subject: Optional[str] = None,
    difficulty: Optional[str] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db),
    _student: Student = Depends(get_current_student),
):
    q = db.query(Course)
    if search:
        q = q.filter(Course.title.ilike(f"%{search}%"))
    if subject:
        q = q.filter(Course.subject == subject)
    if difficulty:
        q = q.filter(Course.difficulty == difficulty)
    if category:
        q = q.filter(Course.category == category)
    return q.all()


@router.get("/courses/{course_id}", response_model=CourseDetailOut)
def course_detail(
    course_id: int,
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")

    enrollment = (
        db.query(Enrollment)
        .filter(Enrollment.student_id == student.id, Enrollment.course_id == course_id)
        .first()
    )
    progress_map = {
        lp.lesson_id: lp
        for lp in db.query(LessonProgress).filter(LessonProgress.student_id == student.id)
    }

    lessons_out = []
    unlocked = True
    for lesson in course.lessons:
        lp = progress_map.get(lesson.id)
        completed = bool(lp and lp.completed)
        lessons_out.append(LessonOut(
            id=lesson.id, title=lesson.title, topic=lesson.topic,
            order_index=lesson.order_index, resource_type=lesson.resource_type.value,
            difficulty=lesson.difficulty.value, content_notes=lesson.content_notes,
            estimated_minutes=lesson.estimated_minutes,
            completed=completed,
            locked=not unlocked and not enrollment,
        ))
        if not completed:
            unlocked = False  # sequential unlock: next lesson stays locked until this one's done

    return CourseDetailOut(
        id=course.id, title=course.title, description=course.description,
        subject=course.subject, category=course.category, difficulty=course.difficulty.value,
        estimated_hours=course.estimated_hours, rating=course.rating,
        num_lessons=course.num_lessons, lessons=lessons_out,
        progress_percent=enrollment.progress_percent if enrollment else 0.0,
        enrolled=enrollment is not None,
    )


@router.post("/courses/{course_id}/enroll", status_code=201)
def enroll(
    course_id: int,
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")

    existing = (
        db.query(Enrollment)
        .filter(Enrollment.student_id == student.id, Enrollment.course_id == course_id)
        .first()
    )
    if existing:
        return {"message": "Already enrolled", "course_id": course_id}

    enrollment = Enrollment(student_id=student.id, course_id=course_id)
    db.add(enrollment)
    db.commit()
    return {"message": "Enrolled", "course_id": course_id}


@router.get("/my-learning", response_model=dict)
def my_learning(
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    enrollments = db.query(Enrollment).filter(Enrollment.student_id == student.id).all()
    progress_map = {
        lp.lesson_id: lp
        for lp in db.query(LessonProgress).filter(LessonProgress.student_id == student.id)
    }

    in_progress, completed = [], []
    for enr in enrollments:
        course = db.query(Course).filter(Course.id == enr.course_id).first()
        total = course.num_lessons
        done = sum(1 for l in course.lessons if progress_map.get(l.id) and progress_map[l.id].completed)

        item = MyLearningCourse(
            course_id=course.id, title=course.title, subject=course.subject,
            progress_percent=enr.progress_percent, completed_lessons=done, total_lessons=total,
            last_accessed=enr.last_accessed, completed=enr.completed,
            final_score=enr.final_score, completed_at=enr.completed_at,
        )
        (completed if enr.completed else in_progress).append(item)

    return {"currently_learning": in_progress, "completed_courses": completed}

from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_student
from app.models import Quiz, Question, QuizAttempt, Course, Enrollment, Student
from app.schemas import QuizOut, QuizDetailOut, QuestionOut, QuizSubmitRequest, QuizResultOut
from app.ml.weak_spot_detection import refresh_topic_performance
from app.ml.recommendation_engine import generate_recommendations

router = APIRouter(prefix="/api/assessments", tags=["assessments"])


@router.get("", response_model=List[QuizOut])
def list_quizzes(db: Session = Depends(get_db), student: Student = Depends(get_current_student)):
    enrolled_course_ids = [
        row[0] for row in db.query(Enrollment.course_id).filter(Enrollment.student_id == student.id).all()
    ]
    if not enrolled_course_ids:
        return []

    quizzes = db.query(Quiz).filter(Quiz.course_id.in_(enrolled_course_ids)).all()
    out = []
    for quiz in quizzes:
        course = db.query(Course).filter(Course.id == quiz.course_id).first()
        attempts = (
            db.query(QuizAttempt)
            .filter(QuizAttempt.quiz_id == quiz.id, QuizAttempt.student_id == student.id)
            .all()
        )
        best = max((a.score_percent for a in attempts), default=None)
        out.append(QuizOut(
            id=quiz.id, title=quiz.title, topic=quiz.topic, difficulty=quiz.difficulty.value,
            course_title=course.title if course else "", num_questions=quiz.num_questions,
            best_score=best, attempt_count=len(attempts),
        ))
    return out


def _require_enrollment(db: Session, student: Student, course_id: int):
    enrolled = (
        db.query(Enrollment)
        .filter(Enrollment.student_id == student.id, Enrollment.course_id == course_id)
        .first()
    )
    if not enrolled:
        raise HTTPException(status_code=403, detail="Enroll in this course to take its quizzes")


@router.get("/{quiz_id}", response_model=QuizDetailOut)
def get_quiz(quiz_id: int, db: Session = Depends(get_db), student: Student = Depends(get_current_student)):
    quiz = db.query(Quiz).filter(Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    _require_enrollment(db, student, quiz.course_id)
    questions = [QuestionOut(id=q.id, text=q.text, options=q.options) for q in quiz.questions]
    return QuizDetailOut(id=quiz.id, title=quiz.title, topic=quiz.topic, difficulty=quiz.difficulty.value, questions=questions)


@router.post("/{quiz_id}/submit", response_model=QuizResultOut)
def submit_quiz(
    quiz_id: int,
    payload: QuizSubmitRequest,
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    quiz = db.query(Quiz).filter(Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    _require_enrollment(db, student, quiz.course_id)

    questions_by_id = {q.id: q for q in quiz.questions}
    correct_count, incorrect_count = 0, 0
    answer_log = []
    for ans in payload.answers:
        question = questions_by_id.get(ans.question_id)
        if not question:
            continue
        is_correct = ans.selected_index == question.correct_option_index
        correct_count += int(is_correct)
        incorrect_count += int(not is_correct)
        answer_log.append({
            "question_id": ans.question_id,
            "selected_index": ans.selected_index,
            "correct": is_correct,
        })

    total = max(len(quiz.questions), 1)
    score_percent = round(100 * correct_count / total, 1)

    attempt = QuizAttempt(
        student_id=student.id, quiz_id=quiz.id, score_percent=score_percent,
        correct_count=correct_count, incorrect_count=incorrect_count,
        answers=answer_log, time_spent_seconds=payload.time_spent_seconds,
        attempted_at=datetime.utcnow(),
    )
    db.add(attempt)
    db.commit()

    # Re-run the analytics + recommendation pipeline with this new signal
    refresh_topic_performance(db, student.id)
    generate_recommendations(db, student.id)

    if score_percent >= 80:
        next_action = f"Great work - you're ready to move on to the next topic in {quiz.topic}."
    elif score_percent >= 60:
        next_action = f"Solid attempt. A quick review of {quiz.topic} before the next assessment will help."
    else:
        next_action = f"You need more practice in {quiz.topic}. Review the lesson material before retrying."

    return QuizResultOut(
        score_percent=score_percent, correct_count=correct_count, incorrect_count=incorrect_count,
        total_questions=len(quiz.questions), topic=quiz.topic, recommended_next_action=next_action,
    )

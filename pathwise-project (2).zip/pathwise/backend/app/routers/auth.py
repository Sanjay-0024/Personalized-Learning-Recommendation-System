from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Student
from app.schemas import SignupRequest, LoginRequest, TokenResponse, StudentOut
from app.auth import hash_password, verify_password, create_access_token

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/signup", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def signup(payload: SignupRequest, db: Session = Depends(get_db)):
    if payload.password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    existing = db.query(Student).filter(Student.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="An account with this email already exists")

    student = Student(
        full_name=payload.full_name,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        last_active_date=datetime.utcnow(),
        current_streak_days=1,
    )
    db.add(student)
    db.commit()
    db.refresh(student)

    token = create_access_token(subject=str(student.id))
    return TokenResponse(access_token=token, student=StudentOut.model_validate(student))


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    student = db.query(Student).filter(Student.email == payload.email).first()
    if not student or not verify_password(payload.password, student.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    _update_streak(db, student)

    token = create_access_token(subject=str(student.id))
    return TokenResponse(access_token=token, student=StudentOut.model_validate(student))


def _update_streak(db: Session, student: Student):
    """Simple day-based streak: increments if the student's last active day
    was yesterday, resets to 1 if there's a gap, unchanged if already today.
    """
    now = datetime.utcnow()
    if student.last_active_date:
        gap_days = (now.date() - student.last_active_date.date()).days
        if gap_days == 1:
            student.current_streak_days += 1
        elif gap_days > 1:
            student.current_streak_days = 1
        # gap_days == 0 -> same day, no change
    else:
        student.current_streak_days = 1
    student.last_active_date = now
    db.commit()

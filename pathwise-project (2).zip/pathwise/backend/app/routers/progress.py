from datetime import datetime, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_student
from app.models import (
    QuizAttempt, Quiz, LessonProgress, TopicPerformance, Enrollment, Student,
)
from app.schemas import (
    ProgressPageOut, ScoreHistoryPoint, TopicPerformanceOut, EngagementAnalytics,
)

router = APIRouter(prefix="/api/progress", tags=["progress"])


@router.get("", response_model=ProgressPageOut)
def get_progress(db: Session = Depends(get_db), student: Student = Depends(get_current_student)):
    attempts = (
        db.query(QuizAttempt, Quiz)
        .join(Quiz, QuizAttempt.quiz_id == Quiz.id)
        .filter(QuizAttempt.student_id == student.id)
        .order_by(QuizAttempt.attempted_at)
        .all()
    )
    score_history = [
        ScoreHistoryPoint(attempted_at=a.attempted_at, score_percent=a.score_percent, topic=q.topic)
        for a, q in attempts
    ]
    average_score = round(sum(a.score_percent for a, _ in attempts) / len(attempts), 1) if attempts else 0.0

    enrollments = db.query(Enrollment).filter(Enrollment.student_id == student.id).all()
    overall_completion = (
        round(sum(e.progress_percent for e in enrollments) / len(enrollments), 1) if enrollments else 0.0
    )

    lesson_progress = db.query(LessonProgress).filter(LessonProgress.student_id == student.id).all()
    lessons_completed = sum(1 for lp in lesson_progress if lp.completed)
    total_time_seconds = sum(lp.time_spent_seconds for lp in lesson_progress) + sum(
        a.time_spent_seconds for a, _ in attempts
    )

    topics = db.query(TopicPerformance).filter(TopicPerformance.student_id == student.id).all()
    topics_out = [
        TopicPerformanceOut(
            topic=t.topic, subject=t.subject, avg_score=t.avg_score, status=t.status.value,
            attempts=t.attempts, time_spent_seconds=t.time_spent_seconds,
        )
        for t in sorted(topics, key=lambda x: x.avg_score)
    ]

    one_week_ago = datetime.utcnow() - timedelta(days=7)
    recent_activity_days = {
        lp.opened_at.date() for lp in lesson_progress if lp.opened_at and lp.opened_at >= one_week_ago
    }

    engagement = EngagementAnalytics(
        learning_frequency_per_week=float(len(recent_activity_days)),
        total_time_spent_minutes=round(total_time_seconds / 60),
        lessons_completed=lessons_completed,
        quiz_attempts=len(attempts),
        resources_accessed=len(lesson_progress),
    )

    return ProgressPageOut(
        average_score=average_score,
        overall_completion_percent=overall_completion,
        total_learning_time_minutes=round(total_time_seconds / 60),
        lessons_completed=lessons_completed,
        quiz_attempts=len(attempts),
        score_history=score_history,
        topics=topics_out,
        engagement=engagement,
    )

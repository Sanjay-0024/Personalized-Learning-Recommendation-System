from typing import Dict, List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_student
from app.models import Recommendation, RecommendationFeedback, Student
from app.schemas import RecommendationOut, RecommendationFeedbackRequest
from app.ml.recommendation_engine import generate_recommendations

router = APIRouter(prefix="/api/recommendations", tags=["recommendations"])


@router.get("", response_model=Dict[str, List[RecommendationOut]])
def get_recommendations(
    refresh: bool = False,
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    active = db.query(Recommendation).filter(
        Recommendation.student_id == student.id, Recommendation.is_active == True  # noqa: E712
    ).all()

    if refresh or not active:
        active = generate_recommendations(db, student.id)

    grouped: Dict[str, List[RecommendationOut]] = {}
    for rec in active:
        grouped.setdefault(rec.category.value, []).append(RecommendationOut.model_validate(rec))
    return grouped


@router.post("/{recommendation_id}/feedback")
def submit_feedback(
    recommendation_id: int,
    payload: RecommendationFeedbackRequest,
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    rec = db.query(Recommendation).filter(Recommendation.id == recommendation_id).first()
    if not rec or rec.student_id != student.id:
        raise HTTPException(status_code=404, detail="Recommendation not found")

    feedback = RecommendationFeedback(
        recommendation_id=recommendation_id, student_id=student.id,
        helpful=payload.helpful, stars=payload.stars,
    )
    db.add(feedback)
    db.commit()
    return {"message": "Feedback recorded"}

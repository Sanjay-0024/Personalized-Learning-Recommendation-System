from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_student
from app.models import (
    Enrollment, LessonProgress, QuizAttempt, TopicPerformance, TopicStatus,
    Recommendation, Student,
)
from app.schemas import (
    DashboardOut, SummaryCards, RecommendationOut, OverallProgress,
    SubjectProgress, LearningInsights,
)
from app.ml.recommendation_engine import generate_recommendations

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("", response_model=DashboardOut)
def get_dashboard(db: Session = Depends(get_db), student: Student = Depends(get_current_student)):
    enrollments = db.query(Enrollment).filter(Enrollment.student_id == student.id).all()
    courses_in_progress = sum(1 for e in enrollments if not e.completed)
    courses_completed = sum(1 for e in enrollments if e.completed)

    completed_lessons = (
        db.query(LessonProgress)
        .filter(LessonProgress.student_id == student.id, LessonProgress.completed == True)  # noqa: E712
        .count()
    )
    total_lessons = sum(e.course.num_lessons for e in enrollments)

    attempts = db.query(QuizAttempt).filter(QuizAttempt.student_id == student.id).all()
    average_score = round(sum(a.score_percent for a in attempts) / len(attempts), 1) if attempts else 0.0

    summary = SummaryCards(
        learning_streak_days=student.current_streak_days,
        courses_in_progress=courses_in_progress,
        completed_lessons=completed_lessons,
        average_score=average_score,
    )

    active_recs = db.query(Recommendation).filter(
        Recommendation.student_id == student.id, Recommendation.is_active == True  # noqa: E712
    ).all()
    if not active_recs:
        active_recs = generate_recommendations(db, student.id)
    top_recs = sorted(active_recs, key=lambda r: r.match_percent, reverse=True)[:4]

    overall_percent = round(100 * courses_completed / len(enrollments), 1) if enrollments else 0.0
    overall_progress = OverallProgress(
        overall_percent=round(sum(e.progress_percent for e in enrollments) / len(enrollments), 1) if enrollments else 0.0,
        lessons_completed=completed_lessons,
        lessons_remaining=max(total_lessons - completed_lessons, 0),
        courses_completed=courses_completed,
        active_courses=courses_in_progress,
    )

    subject_totals = {}
    for e in enrollments:
        subject_totals.setdefault(e.course.subject, []).append(e.progress_percent)
    subject_progress = [
        SubjectProgress(subject=subj, progress_percent=round(sum(vals) / len(vals), 1))
        for subj, vals in subject_totals.items()
    ]

    topics = db.query(TopicPerformance).filter(TopicPerformance.student_id == student.id).all()
    strong = [t.topic for t in topics if t.status == TopicStatus.strong]
    weak = [t.topic for t in topics if t.status == TopicStatus.weak]
    recent_progress = (
        db.query(LessonProgress)
        .filter(LessonProgress.student_id == student.id, LessonProgress.completed == True)  # noqa: E712
        .order_by(LessonProgress.completed_at.desc())
        .limit(3)
        .all()
    )
    recently_learned = [lp.lesson.title for lp in recent_progress]
    next_step = top_recs[0].title if top_recs else None

    insights = LearningInsights(
        strong_areas=strong, needs_improvement=weak,
        recently_learned=recently_learned, recommended_next_step=next_step,
    )

    return DashboardOut(
        student_name=student.full_name,
        learning_goal=student.learning_goal,
        summary=summary,
        recommendations=[RecommendationOut.model_validate(r) for r in top_recs],
        overall_progress=overall_progress,
        subject_progress=subject_progress,
        insights=insights,
    )

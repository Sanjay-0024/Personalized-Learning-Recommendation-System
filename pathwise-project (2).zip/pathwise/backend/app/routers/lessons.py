from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_student
from app.models import Lesson, LessonProgress, Enrollment, Course, Student
from app.schemas import LessonProgressUpdate

router = APIRouter(prefix="/api/lessons", tags=["lessons"])


@router.post("/{lesson_id}/open")
def open_lesson(
    lesson_id: int,
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    lesson = db.query(Lesson).filter(Lesson.id == lesson_id).first()
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")

    progress = (
        db.query(LessonProgress)
        .filter(LessonProgress.lesson_id == lesson_id, LessonProgress.student_id == student.id)
        .first()
    )
    if not progress:
        progress = LessonProgress(student_id=student.id, lesson_id=lesson_id)
        db.add(progress)

    enrollment = (
        db.query(Enrollment)
        .filter(Enrollment.student_id == student.id, Enrollment.course_id == lesson.course_id)
        .first()
    )
    if enrollment:
        enrollment.last_accessed = datetime.utcnow()

    db.commit()
    db.refresh(progress)
    return {"lesson_id": lesson_id, "opened": True}


@router.post("/{lesson_id}/progress")
def update_lesson_progress(
    lesson_id: int,
    payload: LessonProgressUpdate,
    db: Session = Depends(get_db),
    student: Student = Depends(get_current_student),
):
    """Called by the frontend's lesson player periodically (time spent) and
    once when the student marks a lesson complete. This is the raw activity
    feed the learning-analytics / recommendation pipeline reads from.
    """
    lesson = db.query(Lesson).filter(Lesson.id == lesson_id).first()
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")

    progress = (
        db.query(LessonProgress)
        .filter(LessonProgress.lesson_id == lesson_id, LessonProgress.student_id == student.id)
        .first()
    )
    if not progress:
        progress = LessonProgress(student_id=student.id, lesson_id=lesson_id)
        db.add(progress)

    progress.time_spent_seconds += payload.time_spent_seconds
    if payload.completed and not progress.completed:
        progress.completed = True
        progress.completed_at = datetime.utcnow()

    db.commit()
    _recalculate_course_progress(db, student.id, lesson.course_id)
    return {"lesson_id": lesson_id, "completed": progress.completed, "time_spent_seconds": progress.time_spent_seconds}


def _recalculate_course_progress(db: Session, student_id: int, course_id: int):
    course = db.query(Course).filter(Course.id == course_id).first()
    enrollment = (
        db.query(Enrollment)
        .filter(Enrollment.student_id == student_id, Enrollment.course_id == course_id)
        .first()
    )
    if not enrollment or not course.lessons:
        return

    progress_rows = {
        lp.lesson_id: lp
        for lp in db.query(LessonProgress).filter(LessonProgress.student_id == student_id)
    }
    total = len(course.lessons)
    done = sum(1 for l in course.lessons if progress_rows.get(l.id) and progress_rows[l.id].completed)

    enrollment.progress_percent = round(100 * done / total, 1)
    if done == total and not enrollment.completed:
        enrollment.completed = True
        enrollment.completed_at = datetime.utcnow()

    db.commit()

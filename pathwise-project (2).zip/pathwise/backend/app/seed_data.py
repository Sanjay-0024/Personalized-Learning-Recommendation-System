"""
Populates the database with a course catalogue and (optionally) a demo
student that already has quiz history, so the ML pipeline has something to
work with the first time you open the app.

`seed_course_catalogue()` runs automatically on every app startup (see
app/main.py) so a brand new database always has real courses to browse and
enroll in - no manual step required.

To additionally create a demo account with pre-existing activity (useful for
showing weak-spot detection and recommendations working immediately), run:
    python -m app.seed_data
"""
import random
from datetime import datetime, timedelta

from app.database import Base, engine, SessionLocal
from app.models import (
    Student, Course, Lesson, Quiz, Question, QuizAttempt, Enrollment,
    LessonProgress, DifficultyEnum, ResourceTypeEnum,
)
from app.auth import hash_password
from app.ml.weak_spot_detection import refresh_topic_performance
from app.ml.recommendation_engine import generate_recommendations

Base.metadata.create_all(bind=engine)


COURSE_CATALOGUE = [
    {
        "title": "Python Programming Fundamentals",
        "subject": "Python",
        "category": "Programming",
        "difficulty": DifficultyEnum.beginner,
        "estimated_hours": 8,
        "rating": 4.7,
        "description": "Core Python syntax, data types, control flow and functions, built for complete beginners.",
        "lessons": [
            ("Variables & Data Types", "Variables", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Working with Data Types", "Data Types", ResourceTypeEnum.reading, DifficultyEnum.beginner),
            ("Conditional Statements", "Conditions", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Loops in Python", "Loops", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Python Loops Practice", "Loops", ResourceTypeEnum.practice, DifficultyEnum.beginner),
            ("Writing Functions", "Functions", ResourceTypeEnum.video, DifficultyEnum.intermediate),
        ],
    },
    {
        "title": "Data Structures Essentials",
        "subject": "Data Structures",
        "category": "Computer Science",
        "difficulty": DifficultyEnum.intermediate,
        "estimated_hours": 10,
        "rating": 4.6,
        "description": "Arrays, linked lists, stacks, queues and trees with hands-on practice problems.",
        "lessons": [
            ("Arrays & Lists", "Arrays", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Stacks & Queues", "Stacks and Queues", ResourceTypeEnum.video, DifficultyEnum.intermediate),
            ("Linked Lists", "Linked Lists", ResourceTypeEnum.reading, DifficultyEnum.intermediate),
            ("Trees Practice Set", "Trees", ResourceTypeEnum.practice, DifficultyEnum.advanced),
        ],
    },
    {
        "title": "Machine Learning Foundations",
        "subject": "Machine Learning",
        "category": "Data Science",
        "difficulty": DifficultyEnum.intermediate,
        "estimated_hours": 12,
        "rating": 4.8,
        "description": "Supervised and unsupervised learning concepts, model evaluation, and scikit-learn basics.",
        "lessons": [
            ("Intro to Machine Learning", "ML Basics", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Regression Models", "Regression", ResourceTypeEnum.video, DifficultyEnum.intermediate),
            ("Classification Practice", "Classification", ResourceTypeEnum.practice, DifficultyEnum.intermediate),
            ("Model Evaluation Metrics", "Model Evaluation", ResourceTypeEnum.reading, DifficultyEnum.advanced),
        ],
    },
    {
        "title": "Statistics for Data Analysis",
        "subject": "Statistics",
        "category": "Data Science",
        "difficulty": DifficultyEnum.beginner,
        "estimated_hours": 6,
        "rating": 4.5,
        "description": "Descriptive statistics, probability, and hypothesis testing for data-driven decisions.",
        "lessons": [
            ("Mean, Median & Mode", "Descriptive Stats", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Probability Basics", "Probability", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Hypothesis Testing", "Hypothesis Testing", ResourceTypeEnum.reading, DifficultyEnum.intermediate),
        ],
    },
    {
        "title": "Mathematics for Computer Science",
        "subject": "Mathematics",
        "category": "Mathematics",
        "difficulty": DifficultyEnum.beginner,
        "estimated_hours": 9,
        "rating": 4.4,
        "description": "Discrete math, algebra and logic foundations that underpin every CS topic.",
        "lessons": [
            ("Algebra Refresher", "Algebra", ResourceTypeEnum.video, DifficultyEnum.beginner),
            ("Set Theory & Logic", "Logic", ResourceTypeEnum.reading, DifficultyEnum.beginner),
            ("Discrete Math Practice", "Discrete Math", ResourceTypeEnum.practice, DifficultyEnum.intermediate),
        ],
    },
]

# (question text, [options], correct_index)
SAMPLE_QUESTIONS = [
    ("What does the following print? x = 5; print(x + 2)", ["7", "5", "52", "Error"], 0),
    ("Which keyword starts a loop that repeats while a condition is true?", ["for", "while", "if", "def"], 1),
    ("What is the output of len([1, 2, 3])?", ["2", "3", "4", "Error"], 1),
    ("Which of these is NOT a Python data type?", ["list", "tuple", "array", "dict"], 2),
    ("What does `range(3)` produce?", ["0,1,2", "1,2,3", "0,1,2,3", "3"], 0),
]


def seed_course_catalogue(db):
    """Idempotently populates the course catalogue (courses, lessons, quizzes,
    questions). Safe to call on every app startup - it's a no-op once courses
    already exist. This is what guarantees a brand new database always has
    real courses for students to browse and enroll in, without requiring a
    manual seeding step.
    """
    if db.query(Course).count() > 0:
        return 0

    for c in COURSE_CATALOGUE:
        course = Course(
            title=c["title"], subject=c["subject"], category=c["category"],
            difficulty=c["difficulty"], estimated_hours=c["estimated_hours"],
            rating=c["rating"], description=c["description"],
        )
        db.add(course)
        db.flush()

        for idx, (title, topic, rtype, diff) in enumerate(c["lessons"]):
            lesson = Lesson(
                course_id=course.id, title=title, topic=topic, order_index=idx,
                resource_type=rtype, difficulty=diff,
                content_notes=f"Study material and examples for {title}.",
                estimated_minutes=random.choice([10, 15, 20, 25]),
            )
            db.add(lesson)
            db.flush()

            quiz = Quiz(
                lesson_id=lesson.id, course_id=course.id,
                title=f"{topic} Quiz", topic=topic, difficulty=diff,
            )
            db.add(quiz)
            db.flush()
            for q_text, options, correct in random.sample(SAMPLE_QUESTIONS, k=3):
                db.add(Question(quiz_id=quiz.id, text=q_text, options=options, correct_option_index=correct))
    db.commit()
    return len(COURSE_CATALOGUE)


def run():
    """Full seed used for local/demo setup: course catalogue + a demo student
    with pre-existing activity, so the ML pipeline has something to show
    immediately. Run with `python -m app.seed_data`.
    """
    db = SessionLocal()
    try:
        seeded = seed_course_catalogue(db)
        if seeded:
            print(f"Seeded {seeded} courses.")
        else:
            print("Database already seeded, skipping course catalogue.")

        demo = db.query(Student).filter(Student.email == "demo@pathwise.app").first()
        if demo:
            print("Demo student already exists, skipping.")
        else:
            demo = Student(
                full_name="Asha Rao", email="demo@pathwise.app",
                hashed_password=hash_password("password123"),
                learning_goal="Finish the Python Programming Fundamentals course this week",
                current_streak_days=12, last_active_date=datetime.utcnow(),
            )
            db.add(demo)
            db.commit()
            db.refresh(demo)
            _generate_demo_activity(db, demo)
            print("Demo student created: demo@pathwise.app / password123")
    finally:
        db.close()


def _generate_demo_activity(db, student):
    python_course = db.query(Course).filter(Course.subject == "Python").first()
    ds_course = db.query(Course).filter(Course.subject == "Data Structures").first()

    for course, target_progress in [(python_course, 0.85), (ds_course, 0.3)]:
        db.add(Enrollment(student_id=student.id, course_id=course.id, progress_percent=0))
        db.flush()

        lessons = course.lessons
        num_complete = int(len(lessons) * target_progress)
        for i, lesson in enumerate(lessons):
            completed = i < num_complete
            progress = LessonProgress(
                student_id=student.id, lesson_id=lesson.id,
                opened_at=datetime.utcnow() - timedelta(days=len(lessons) - i),
                time_spent_seconds=random.randint(300, 1200),
                completed=completed,
                completed_at=datetime.utcnow() - timedelta(days=len(lessons) - i) if completed else None,
            )
            db.add(progress)

            if lesson.quiz and completed:
                # Deliberately make "Loops" weak and everything else strong/average,
                # matching the worked example in the project brief.
                base_score = 45 if lesson.topic == "Loops" else random.randint(75, 95)
                for attempt_num in range(random.randint(1, 2)):
                    db.add(QuizAttempt(
                        student_id=student.id, quiz_id=lesson.quiz.id,
                        score_percent=base_score + random.randint(-5, 5),
                        correct_count=2, incorrect_count=1,
                        answers=[], time_spent_seconds=random.randint(60, 300),
                        attempted_at=datetime.utcnow() - timedelta(days=len(lessons) - i, hours=attempt_num),
                    ))
        db.commit()
        enr = db.query(Enrollment).filter(
            Enrollment.student_id == student.id, Enrollment.course_id == course.id
        ).first()
        enr.progress_percent = round(100 * num_complete / len(lessons), 1)
        db.commit()

    refresh_topic_performance(db, student.id)
    generate_recommendations(db, student.id)


if __name__ == "__main__":
    run()

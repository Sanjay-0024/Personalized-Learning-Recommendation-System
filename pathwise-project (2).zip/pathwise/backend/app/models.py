import enum
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, ForeignKey, DateTime, Text, JSON, Enum
)
from sqlalchemy.orm import relationship

from app.database import Base


class DifficultyEnum(str, enum.Enum):
    beginner = "Beginner"
    intermediate = "Intermediate"
    advanced = "Advanced"


class ResourceTypeEnum(str, enum.Enum):
    video = "Video"
    reading = "Reading"
    practice = "Practice"
    quiz = "Quiz"
    example = "Example"


class RecommendationCategory(str, enum.Enum):
    recommended_for_you = "Recommended For You"
    weak_areas = "Improve Your Weak Areas"
    continue_learning = "Continue Learning"
    practice_more = "Practice More"
    challenge = "Challenge Yourself"


class TopicStatus(str, enum.Enum):
    strong = "Strong"
    average = "Average"
    weak = "Weak"


class Student(Base):
    __tablename__ = "students"

    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String(120), nullable=False)
    email = Column(String(180), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    learning_goal = Column(String(255), default="Finish this week's active courses")
    current_streak_days = Column(Integer, default=0)
    last_active_date = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    enrollments = relationship("Enrollment", back_populates="student", cascade="all, delete-orphan")
    lesson_progress = relationship("LessonProgress", back_populates="student", cascade="all, delete-orphan")
    quiz_attempts = relationship("QuizAttempt", back_populates="student", cascade="all, delete-orphan")
    topic_performance = relationship("TopicPerformance", back_populates="student", cascade="all, delete-orphan")
    recommendations = relationship("Recommendation", back_populates="student", cascade="all, delete-orphan")


class Course(Base):
    __tablename__ = "courses"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, default="")
    subject = Column(String(100), nullable=False)
    category = Column(String(100), default="General")
    difficulty = Column(Enum(DifficultyEnum), default=DifficultyEnum.beginner)
    estimated_hours = Column(Float, default=1.0)
    rating = Column(Float, default=4.5)

    lessons = relationship("Lesson", back_populates="course", cascade="all, delete-orphan", order_by="Lesson.order_index")
    enrollments = relationship("Enrollment", back_populates="course")

    @property
    def num_lessons(self):
        return len(self.lessons)


class Lesson(Base):
    __tablename__ = "lessons"

    id = Column(Integer, primary_key=True, index=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    title = Column(String(200), nullable=False)
    topic = Column(String(120), nullable=False)
    order_index = Column(Integer, default=0)
    resource_type = Column(Enum(ResourceTypeEnum), default=ResourceTypeEnum.video)
    difficulty = Column(Enum(DifficultyEnum), default=DifficultyEnum.beginner)
    content_notes = Column(Text, default="")
    estimated_minutes = Column(Integer, default=15)

    course = relationship("Course", back_populates="lessons")
    quiz = relationship("Quiz", back_populates="lesson", uselist=False)


class Enrollment(Base):
    __tablename__ = "enrollments"

    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    enrolled_at = Column(DateTime, default=datetime.utcnow)
    last_accessed = Column(DateTime, default=datetime.utcnow)
    progress_percent = Column(Float, default=0.0)
    completed = Column(Boolean, default=False)
    completed_at = Column(DateTime, nullable=True)
    final_score = Column(Float, nullable=True)

    student = relationship("Student", back_populates="enrollments")
    course = relationship("Course", back_populates="enrollments")


class LessonProgress(Base):
    __tablename__ = "lesson_progress"

    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    lesson_id = Column(Integer, ForeignKey("lessons.id"), nullable=False)
    opened_at = Column(DateTime, default=datetime.utcnow)
    time_spent_seconds = Column(Integer, default=0)
    completed = Column(Boolean, default=False)
    completed_at = Column(DateTime, nullable=True)

    student = relationship("Student", back_populates="lesson_progress")
    lesson = relationship("Lesson")


class Quiz(Base):
    __tablename__ = "quizzes"

    id = Column(Integer, primary_key=True, index=True)
    lesson_id = Column(Integer, ForeignKey("lessons.id"), nullable=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    title = Column(String(200), nullable=False)
    topic = Column(String(120), nullable=False)
    difficulty = Column(Enum(DifficultyEnum), default=DifficultyEnum.beginner)

    lesson = relationship("Lesson", back_populates="quiz")
    questions = relationship("Question", back_populates="quiz", cascade="all, delete-orphan")
    attempts = relationship("QuizAttempt", back_populates="quiz")

    @property
    def num_questions(self):
        return len(self.questions)


class Question(Base):
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True, index=True)
    quiz_id = Column(Integer, ForeignKey("quizzes.id"), nullable=False)
    text = Column(Text, nullable=False)
    options = Column(JSON, nullable=False)  # list[str]
    correct_option_index = Column(Integer, nullable=False)

    quiz = relationship("Quiz", back_populates="questions")


class QuizAttempt(Base):
    __tablename__ = "quiz_attempts"

    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    quiz_id = Column(Integer, ForeignKey("quizzes.id"), nullable=False)
    score_percent = Column(Float, nullable=False)
    correct_count = Column(Integer, default=0)
    incorrect_count = Column(Integer, default=0)
    answers = Column(JSON, default=list)  # list[{question_id, selected_index, correct}]
    attempted_at = Column(DateTime, default=datetime.utcnow)
    time_spent_seconds = Column(Integer, default=0)

    student = relationship("Student", back_populates="quiz_attempts")
    quiz = relationship("Quiz", back_populates="attempts")


class TopicPerformance(Base):
    """Aggregated, continuously-updated analytics row per student/topic.

    This table is written by the learning-analytics job in app.ml and read
    everywhere the UI needs weak/strong topic data, so the recommendation
    engine and the dashboard never disagree about a student's standing.
    """
    __tablename__ = "topic_performance"

    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    topic = Column(String(120), nullable=False)
    subject = Column(String(100), nullable=False)
    avg_score = Column(Float, default=0.0)
    attempts = Column(Integer, default=0)
    time_spent_seconds = Column(Integer, default=0)
    completion_rate = Column(Float, default=0.0)
    status = Column(Enum(TopicStatus), default=TopicStatus.average)
    last_updated = Column(DateTime, default=datetime.utcnow)

    student = relationship("Student", back_populates="topic_performance")


class Recommendation(Base):
    __tablename__ = "recommendations"

    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    title = Column(String(200), nullable=False)
    topic = Column(String(120), nullable=False)
    subject = Column(String(100), nullable=False)
    resource_type = Column(Enum(ResourceTypeEnum), default=ResourceTypeEnum.practice)
    difficulty = Column(Enum(DifficultyEnum), default=DifficultyEnum.beginner)
    match_percent = Column(Float, nullable=False)
    reason = Column(Text, nullable=False)
    category = Column(Enum(RecommendationCategory), default=RecommendationCategory.recommended_for_you)
    lesson_id = Column(Integer, ForeignKey("lessons.id"), nullable=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=True)
    generated_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

    student = relationship("Student", back_populates="recommendations")
    feedback = relationship("RecommendationFeedback", back_populates="recommendation", cascade="all, delete-orphan")


class RecommendationFeedback(Base):
    __tablename__ = "recommendation_feedback"

    id = Column(Integer, primary_key=True, index=True)
    recommendation_id = Column(Integer, ForeignKey("recommendations.id"), nullable=False)
    student_id = Column(Integer, ForeignKey("students.id"), nullable=False)
    helpful = Column(Boolean, nullable=False)
    stars = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    recommendation = relationship("Recommendation", back_populates="feedback")

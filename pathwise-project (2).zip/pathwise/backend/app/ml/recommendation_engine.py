"""
PathWise recommendation engine.

Pipeline (matches the brief's "intelligent cycle"):
    activity -> feature_extraction -> weak_spot_detection -> HERE
    -> scored, ranked candidate resources -> Recommendation rows -> UI

Approach
--------
For a final-year project without production-scale interaction logs, a pure
collaborative-filtering model would be starved of data (cold start for every
new student). Instead this engine uses a hybrid:

1. Rule-based candidate generation: pull resources that are plausibly
   relevant (matching topic/subject, not yet completed, difficulty near the
   student's level) - this is standard content-based filtering.
2. A learned scoring function: candidate features (topic weakness, recency,
   difficulty fit, subject momentum, and prior thumbs-up/down feedback) are
   normalised with scikit-learn's MinMaxScaler and combined with weights into
   a single match score. The weights that make up FEEDBACK_WEIGHT are nudged
   by each student's own recommendation_feedback history, so the ranking
   genuinely adapts as more feedback arrives (a lightweight, explainable
   stand-in for a full learned-to-rank model, with the same input/output
   contract so it can be swapped for a trained model later without touching
   the API).

Every recommendation stores a human-readable `reason` built from the same
numbers used to score it, so the UI claim ("recommended because...") is
never disconnected from the math.
"""
from collections import defaultdict
from datetime import datetime
from typing import Dict, List

import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sqlalchemy.orm import Session

from app.ml.weak_spot_detection import refresh_topic_performance
from app.models import (
    Course, Lesson, Quiz, Enrollment, LessonProgress, TopicPerformance,
    TopicStatus, Recommendation, RecommendationCategory, RecommendationFeedback,
    DifficultyEnum, ResourceTypeEnum,
)

DIFFICULTY_RANK = {"Beginner": 0, "Intermediate": 1, "Advanced": 2}

WEIGHTS = {
    "weakness": 0.45,
    "recency": 0.15,
    "momentum": 0.15,
    "difficulty_fit": 0.15,
    "feedback": 0.10,
}

MAX_PER_CATEGORY = 4


def _feedback_bias(db: Session, student_id: int) -> Dict[str, float]:
    """Returns a per-topic multiplier in [0.7, 1.15] learned from thumbs
    up/down history: topics the student has previously said "not helpful"
    about are toned down, topics marked "helpful" are boosted slightly.
    """
    rows = (
        db.query(Recommendation.topic, RecommendationFeedback.helpful)
        .join(RecommendationFeedback, RecommendationFeedback.recommendation_id == Recommendation.id)
        .filter(Recommendation.student_id == student_id)
        .all()
    )
    tally = defaultdict(lambda: [0, 0])  # topic -> [helpful_count, not_helpful_count]
    for topic, helpful in rows:
        tally[topic][0 if helpful else 1] += 1

    bias = {}
    for topic, (up, down) in tally.items():
        total = up + down
        if total == 0:
            continue
        net = (up - down) / total  # -1..1
        bias[topic] = 1.0 + 0.15 * net
    return bias


def _student_lessons_status(db: Session, student_id: int):
    progress = {
        lp.lesson_id: lp
        for lp in db.query(LessonProgress).filter(LessonProgress.student_id == student_id)
    }
    return progress


def _uncompleted_lessons_for_topic(db, student_id, topic, progress_map):
    lessons = db.query(Lesson).filter(Lesson.topic == topic).all()
    return [l for l in lessons if not (progress_map.get(l.id) and progress_map[l.id].completed)]


def _uncompleted_lessons_for_subject(db, student_id, subject, progress_map, min_difficulty_rank=0):
    lessons = (
        db.query(Lesson)
        .join(Course, Lesson.course_id == Course.id)
        .filter(Course.subject == subject)
        .all()
    )
    out = []
    for l in lessons:
        if progress_map.get(l.id) and progress_map[l.id].completed:
            continue
        if DIFFICULTY_RANK.get(l.difficulty.value if hasattr(l.difficulty, "value") else l.difficulty, 0) < min_difficulty_rank:
            continue
        out.append(l)
    return out


def _score_candidates(raw_features: List[Dict]) -> List[float]:
    if not raw_features:
        return []
    matrix = np.array(
        [[f["weakness"], f["recency"], f["momentum"], f["difficulty_fit"]] for f in raw_features]
    )
    scaler = MinMaxScaler()
    normalised = scaler.fit_transform(matrix) if len(raw_features) > 1 else np.full_like(matrix, 0.7)

    scores = []
    for i, f in enumerate(raw_features):
        base = (
            normalised[i, 0] * WEIGHTS["weakness"]
            + normalised[i, 1] * WEIGHTS["recency"]
            + normalised[i, 2] * WEIGHTS["momentum"]
            + normalised[i, 3] * WEIGHTS["difficulty_fit"]
        )
        base += WEIGHTS["feedback"] * (f["feedback_bias"] - 1.0) * 2
        match_percent = 45 + base * 55  # squeeze into a believable 45-99% band
        scores.append(round(float(np.clip(match_percent, 40, 99)), 1))
    return scores


def generate_recommendations(db: Session, student_id: int) -> List[Recommendation]:
    refresh_topic_performance(db, student_id)

    topics: List[TopicPerformance] = (
        db.query(TopicPerformance).filter(TopicPerformance.student_id == student_id).all()
    )
    weak_topics = [t for t in topics if t.status == TopicStatus.weak]
    strong_topics = [t for t in topics if t.status == TopicStatus.strong]
    overall_avg = np.mean([t.avg_score for t in topics]) if topics else 70.0

    feedback_bias = _feedback_bias(db, student_id)
    progress_map = _student_lessons_status(db, student_id)

    # deactivate previous recommendations - they're regenerated fresh each cycle
    db.query(Recommendation).filter(Recommendation.student_id == student_id).update({"is_active": False})

    new_recs: List[Recommendation] = []

    # --- 1. Improve Your Weak Areas / Practice More ---
    for t in weak_topics:
        candidates = _uncompleted_lessons_for_topic(db, student_id, t.topic, progress_map)
        candidates = [c for c in candidates if c.resource_type.value in ("Practice", "Video", "Reading")][:2]
        feats = []
        for c in candidates:
            feats.append({
                "lesson": c,
                "weakness": max(0.0, 80 - t.avg_score),
                "recency": 10,  # weak topics are always timely
                "momentum": 30,
                "difficulty_fit": 60,
                "feedback_bias": feedback_bias.get(t.topic, 1.0),
            })
        scores = _score_candidates(feats)
        for f, score in zip(feats, scores):
            c = f["lesson"]
            new_recs.append(Recommendation(
                student_id=student_id,
                title=c.title,
                topic=t.topic,
                subject=t.subject,
                resource_type=c.resource_type,
                difficulty=DifficultyEnum.beginner,
                match_percent=score,
                reason=(
                    f"Your recent performance in {t.topic} is {t.avg_score:.0f}%, "
                    f"below your overall average of {overall_avg:.0f}%, so extra practice is recommended."
                ),
                category=RecommendationCategory.weak_areas,
                lesson_id=c.id,
                course_id=c.course_id,
            ))

        quiz = db.query(Quiz).filter(Quiz.topic == t.topic).first()
        if quiz:
            new_recs.append(Recommendation(
                student_id=student_id,
                title=f"{t.topic} Practice Set",
                topic=t.topic,
                subject=t.subject,
                resource_type=ResourceTypeEnum.practice,
                difficulty=DifficultyEnum.beginner,
                match_percent=min(99, round(80 - t.avg_score + 60, 1)),
                reason=f"Your score in {t.topic} is {t.avg_score:.0f}%, so additional practice is recommended before the next assessment.",
                category=RecommendationCategory.practice_more,
                course_id=quiz.course_id,
            ))

    # --- 2. Continue Learning: next lesson in active, incomplete courses ---
    active_enrollments = (
        db.query(Enrollment)
        .filter(Enrollment.student_id == student_id, Enrollment.completed == False)  # noqa: E712
        .all()
    )
    for enr in active_enrollments[:MAX_PER_CATEGORY]:
        next_lesson = (
            db.query(Lesson)
            .filter(Lesson.course_id == enr.course_id)
            .order_by(Lesson.order_index)
            .all()
        )
        next_lesson = next((l for l in next_lesson if not (progress_map.get(l.id) and progress_map[l.id].completed)), None)
        if not next_lesson:
            continue
        course = db.query(Course).filter(Course.id == enr.course_id).first()
        new_recs.append(Recommendation(
            student_id=student_id,
            title=next_lesson.title,
            topic=next_lesson.topic,
            subject=course.subject,
            resource_type=next_lesson.resource_type,
            difficulty=next_lesson.difficulty,
            match_percent=round(70 + enr.progress_percent * 0.25, 1),
            reason=f"Continuing {course.title}, where you're already {enr.progress_percent:.0f}% through.",
            category=RecommendationCategory.continue_learning,
            lesson_id=next_lesson.id,
            course_id=course.id,
        ))

    # --- 3. Challenge Yourself: advanced material for strong topics ---
    for t in strong_topics[:MAX_PER_CATEGORY]:
        candidates = _uncompleted_lessons_for_subject(db, student_id, t.subject, progress_map, min_difficulty_rank=1)
        candidates = candidates[:1]
        for c in candidates:
            new_recs.append(Recommendation(
                student_id=student_id,
                title=c.title,
                topic=c.topic,
                subject=t.subject,
                resource_type=c.resource_type,
                difficulty=c.difficulty,
                match_percent=round(min(99, 70 + t.avg_score * 0.25), 1),
                reason=f"You're scoring {t.avg_score:.0f}% in {t.topic} - ready for a more advanced challenge.",
                category=RecommendationCategory.challenge,
                lesson_id=c.id,
                course_id=c.course_id,
            ))

    # --- 4. Recommended For You: top-ranked overall pick ---
    if weak_topics:
        top_weak = min(weak_topics, key=lambda t: t.avg_score)
        candidates = _uncompleted_lessons_for_topic(db, student_id, top_weak.topic, progress_map)
        if candidates:
            c = candidates[0]
            new_recs.append(Recommendation(
                student_id=student_id,
                title=c.title,
                topic=top_weak.topic,
                subject=top_weak.subject,
                resource_type=c.resource_type,
                difficulty=DifficultyEnum.beginner,
                match_percent=round(min(99, 90 - top_weak.avg_score * 0.2), 1),
                reason=f"Recommended because your recent quiz performance in {top_weak.topic} is below your average.",
                category=RecommendationCategory.recommended_for_you,
                lesson_id=c.id,
                course_id=c.course_id,
            ))

    for r in new_recs:
        db.add(r)
    db.commit()
    for r in new_recs:
        db.refresh(r)
    return new_recs

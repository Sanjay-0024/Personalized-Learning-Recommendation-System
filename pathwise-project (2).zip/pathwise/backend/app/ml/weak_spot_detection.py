"""
Weak-spot detection.

Reads the feature table from feature_extraction and classifies every topic a
student has attempted into Strong / Average / Weak, purely from behavioural
signals (score, attempts, completion, recency) - never set by an admin. The
result is written to the topic_performance table so every other page reads
the same numbers.

Thresholds are intentionally simple and documented so they're easy to defend
in a viva: a topic is "weak" if the score-weighted confidence estimate falls
below WEAK_THRESHOLD, "strong" if it clears STRONG_THRESHOLD, else "average".
Confidence widens the band for topics with very few attempts, so a single
lucky/unlucky quiz doesn't immediately relabel a topic.
"""
from datetime import datetime

from sqlalchemy.orm import Session

from app.ml.feature_extraction import build_topic_feature_table
from app.models import TopicPerformance, TopicStatus

STRONG_THRESHOLD = 80.0
WEAK_THRESHOLD = 60.0


def _confidence_adjusted_score(avg_score: float, attempts: int) -> float:
    """Pulls low-attempt scores toward the middle (50) so we don't
    over-react to a single quiz. More attempts -> trust the raw average more.
    """
    weight = min(attempts / 3.0, 1.0)  # full trust after 3 attempts
    return avg_score * weight + 50.0 * (1 - weight)


def classify_topic(avg_score: float, attempts: int) -> TopicStatus:
    adjusted = _confidence_adjusted_score(avg_score, attempts)
    if adjusted >= STRONG_THRESHOLD:
        return TopicStatus.strong
    if adjusted < WEAK_THRESHOLD:
        return TopicStatus.weak
    return TopicStatus.average


def refresh_topic_performance(db: Session, student_id: int) -> None:
    """Recomputes and upserts topic_performance rows for one student.
    Call this after every quiz submission / lesson completion.
    """
    features = build_topic_feature_table(db, student_id)

    existing = {
        tp.topic: tp
        for tp in db.query(TopicPerformance).filter(TopicPerformance.student_id == student_id)
    }

    seen_topics = set()
    for _, row in features.iterrows():
        status = classify_topic(row["avg_score"], row["attempts"])
        seen_topics.add(row["topic"])

        if row["topic"] in existing:
            tp = existing[row["topic"]]
            tp.avg_score = row["avg_score"]
            tp.attempts = row["attempts"]
            tp.time_spent_seconds = row["time_spent_seconds"]
            tp.completion_rate = row["completion_rate"]
            tp.status = status
            tp.last_updated = datetime.utcnow()
        else:
            db.add(
                TopicPerformance(
                    student_id=student_id,
                    topic=row["topic"],
                    subject=row["subject"],
                    avg_score=row["avg_score"],
                    attempts=row["attempts"],
                    time_spent_seconds=row["time_spent_seconds"],
                    completion_rate=row["completion_rate"],
                    status=status,
                    last_updated=datetime.utcnow(),
                )
            )

    db.commit()

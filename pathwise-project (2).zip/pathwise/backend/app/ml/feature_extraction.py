"""
Feature extraction for the PathWise recommendation engine.

Turns raw activity rows (quiz attempts, lesson progress, enrollments) into a
per-student, per-topic feature table that the rest of the ML pipeline
(weak_spot_detection, recommendation_engine) can consume. Keeping this in one
place means the dashboard's "Learning Insights" and the recommendation engine
are always computed from the same numbers.
"""
from datetime import datetime
from typing import Dict, List

import numpy as np
import pandas as pd
from sqlalchemy.orm import Session

from app.models import QuizAttempt, Quiz, LessonProgress, Lesson, Enrollment


def build_topic_feature_table(db: Session, student_id: int) -> pd.DataFrame:
    """Returns one row per topic the student has touched, with columns:

    topic, subject, avg_score, best_score, attempts, time_spent_seconds,
    completion_rate, recency_days, score_trend
    """
    attempts = (
        db.query(QuizAttempt, Quiz)
        .join(Quiz, QuizAttempt.quiz_id == Quiz.id)
        .filter(QuizAttempt.student_id == student_id)
        .all()
    )

    rows: List[Dict] = []
    for attempt, quiz in attempts:
        rows.append(
            {
                "topic": quiz.topic,
                "subject": _subject_for_quiz(db, quiz),
                "score": attempt.score_percent,
                "attempted_at": attempt.attempted_at,
                "time_spent_seconds": attempt.time_spent_seconds,
            }
        )

    if not rows:
        return pd.DataFrame(
            columns=[
                "topic", "subject", "avg_score", "best_score", "attempts",
                "time_spent_seconds", "completion_rate", "recency_days", "score_trend",
            ]
        )

    df = pd.DataFrame(rows)
    now = datetime.utcnow()

    grouped = []
    for topic, group in df.groupby("topic"):
        group_sorted = group.sort_values("attempted_at")
        scores = group_sorted["score"].to_numpy(dtype=float)

        # score_trend: slope of a 1-degree fit over attempt order, positive = improving
        if len(scores) >= 2:
            x = np.arange(len(scores))
            slope = np.polyfit(x, scores, 1)[0]
        else:
            slope = 0.0

        latest_attempt = group_sorted["attempted_at"].iloc[-1]
        recency_days = max((now - latest_attempt).days, 0)

        grouped.append(
            {
                "topic": topic,
                "subject": group_sorted["subject"].iloc[0],
                "avg_score": float(scores.mean()),
                "best_score": float(scores.max()),
                "attempts": int(len(scores)),
                "time_spent_seconds": int(group_sorted["time_spent_seconds"].sum()),
                "completion_rate": _completion_rate_for_topic(db, student_id, topic),
                "recency_days": recency_days,
                "score_trend": float(slope),
            }
        )

    return pd.DataFrame(grouped)


def _subject_for_quiz(db: Session, quiz: Quiz) -> str:
    course = quiz.course_id
    from app.models import Course
    c = db.query(Course).filter(Course.id == course).first()
    return c.subject if c else "General"


def _completion_rate_for_topic(db: Session, student_id: int, topic: str) -> float:
    lessons = (
        db.query(Lesson, LessonProgress)
        .outerjoin(
            LessonProgress,
            (LessonProgress.lesson_id == Lesson.id) & (LessonProgress.student_id == student_id),
        )
        .filter(Lesson.topic == topic)
        .all()
    )
    if not lessons:
        return 0.0
    total = len(lessons)
    completed = sum(1 for _, progress in lessons if progress and progress.completed)
    return round(completed / total, 3)

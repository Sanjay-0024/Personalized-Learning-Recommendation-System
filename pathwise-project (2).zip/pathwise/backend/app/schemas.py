from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field


# ---------- Auth ----------

class SignupRequest(BaseModel):
    full_name: str
    email: EmailStr
    password: str = Field(min_length=6)
    confirm_password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    student: "StudentOut"


class StudentOut(BaseModel):
    id: int
    full_name: str
    email: EmailStr
    learning_goal: str
    current_streak_days: int

    class Config:
        from_attributes = True


# ---------- Courses / Lessons ----------

class LessonOut(BaseModel):
    id: int
    title: str
    topic: str
    order_index: int
    resource_type: str
    difficulty: str
    content_notes: str
    estimated_minutes: int
    completed: bool = False
    locked: bool = False

    class Config:
        from_attributes = True


class CourseOut(BaseModel):
    id: int
    title: str
    description: str
    subject: str
    category: str
    difficulty: str
    estimated_hours: float
    rating: float
    num_lessons: int

    class Config:
        from_attributes = True


class CourseDetailOut(CourseOut):
    lessons: List[LessonOut]
    progress_percent: float = 0.0
    enrolled: bool = False


class MyLearningCourse(BaseModel):
    course_id: int
    title: str
    subject: str
    progress_percent: float
    completed_lessons: int
    total_lessons: int
    last_accessed: datetime
    completed: bool
    final_score: Optional[float] = None
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# ---------- Lesson progress ----------

class LessonProgressUpdate(BaseModel):
    time_spent_seconds: int = 0
    completed: bool = False


# ---------- Quizzes / Assessments ----------

class QuestionOut(BaseModel):
    id: int
    text: str
    options: List[str]

    class Config:
        from_attributes = True


class QuizOut(BaseModel):
    id: int
    title: str
    topic: str
    difficulty: str
    course_title: str
    num_questions: int
    best_score: Optional[float] = None
    attempt_count: int = 0

    class Config:
        from_attributes = True


class QuizDetailOut(BaseModel):
    id: int
    title: str
    topic: str
    difficulty: str
    questions: List[QuestionOut]

    class Config:
        from_attributes = True


class QuizSubmitAnswer(BaseModel):
    question_id: int
    selected_index: int


class QuizSubmitRequest(BaseModel):
    answers: List[QuizSubmitAnswer]
    time_spent_seconds: int = 0


class QuizResultOut(BaseModel):
    score_percent: float
    correct_count: int
    incorrect_count: int
    total_questions: int
    topic: str
    recommended_next_action: str


# ---------- Dashboard ----------

class SummaryCards(BaseModel):
    learning_streak_days: int
    courses_in_progress: int
    completed_lessons: int
    average_score: float


class RecommendationOut(BaseModel):
    id: int
    title: str
    topic: str
    subject: str
    resource_type: str
    difficulty: str
    match_percent: float
    reason: str
    category: str
    lesson_id: Optional[int] = None
    course_id: Optional[int] = None

    class Config:
        from_attributes = True


class OverallProgress(BaseModel):
    overall_percent: float
    lessons_completed: int
    lessons_remaining: int
    courses_completed: int
    active_courses: int


class SubjectProgress(BaseModel):
    subject: str
    progress_percent: float


class LearningInsights(BaseModel):
    strong_areas: List[str]
    needs_improvement: List[str]
    recently_learned: List[str]
    recommended_next_step: Optional[str] = None


class DashboardOut(BaseModel):
    student_name: str
    learning_goal: str
    summary: SummaryCards
    recommendations: List[RecommendationOut]
    overall_progress: OverallProgress
    subject_progress: List[SubjectProgress]
    insights: LearningInsights


# ---------- Progress / Analytics ----------

class TopicPerformanceOut(BaseModel):
    topic: str
    subject: str
    avg_score: float
    status: str
    attempts: int
    time_spent_seconds: int

    class Config:
        from_attributes = True


class ScoreHistoryPoint(BaseModel):
    attempted_at: datetime
    score_percent: float
    topic: str


class EngagementAnalytics(BaseModel):
    learning_frequency_per_week: float
    total_time_spent_minutes: int
    lessons_completed: int
    quiz_attempts: int
    resources_accessed: int


class ProgressPageOut(BaseModel):
    average_score: float
    overall_completion_percent: float
    total_learning_time_minutes: int
    lessons_completed: int
    quiz_attempts: int
    score_history: List[ScoreHistoryPoint]
    topics: List[TopicPerformanceOut]
    engagement: EngagementAnalytics


# ---------- Feedback ----------

class RecommendationFeedbackRequest(BaseModel):
    helpful: bool
    stars: Optional[int] = Field(default=None, ge=1, le=5)


TokenResponse.model_rebuild()

-- PathWise reference schema (MySQL 8.0+).
-- app/main.py calls Base.metadata.create_all() and builds this for you
-- automatically on first run; this file is provided for documentation and
-- for anyone who wants to inspect/version the schema directly.

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(180) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    learning_goal VARCHAR(255) DEFAULT 'Finish this week''s active courses',
    current_streak_days INT DEFAULT 0,
    last_active_date DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    subject VARCHAR(100) NOT NULL,
    category VARCHAR(100) DEFAULT 'General',
    difficulty ENUM('Beginner','Intermediate','Advanced') DEFAULT 'Beginner',
    estimated_hours FLOAT DEFAULT 1.0,
    rating FLOAT DEFAULT 4.5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT,
    title VARCHAR(200) NOT NULL,
    topic VARCHAR(120) NOT NULL,
    order_index INT DEFAULT 0,
    resource_type ENUM('Video','Reading','Practice','Quiz','Example') DEFAULT 'Video',
    difficulty ENUM('Beginner','Intermediate','Advanced') DEFAULT 'Beginner',
    content_notes TEXT,
    estimated_minutes INT DEFAULT 15,
    FOREIGN KEY (course_id) REFERENCES courses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    enrolled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_accessed DATETIME DEFAULT CURRENT_TIMESTAMP,
    progress_percent FLOAT DEFAULT 0.0,
    completed BOOLEAN DEFAULT FALSE,
    completed_at DATETIME,
    final_score FLOAT,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE lesson_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    lesson_id INT,
    opened_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    time_spent_seconds INT DEFAULT 0,
    completed BOOLEAN DEFAULT FALSE,
    completed_at DATETIME,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lesson_id INT,
    course_id INT,
    title VARCHAR(200) NOT NULL,
    topic VARCHAR(120) NOT NULL,
    difficulty ENUM('Beginner','Intermediate','Advanced') DEFAULT 'Beginner',
    FOREIGN KEY (lesson_id) REFERENCES lessons(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT,
    text TEXT NOT NULL,
    options JSON NOT NULL,
    correct_option_index INT NOT NULL,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE quiz_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    quiz_id INT,
    score_percent FLOAT NOT NULL,
    correct_count INT DEFAULT 0,
    incorrect_count INT DEFAULT 0,
    answers JSON,
    attempted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    time_spent_seconds INT DEFAULT 0,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE topic_performance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    topic VARCHAR(120) NOT NULL,
    subject VARCHAR(100) NOT NULL,
    avg_score FLOAT DEFAULT 0.0,
    attempts INT DEFAULT 0,
    time_spent_seconds INT DEFAULT 0,
    completion_rate FLOAT DEFAULT 0.0,
    status ENUM('Strong','Average','Weak') DEFAULT 'Average',
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE recommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    title VARCHAR(200) NOT NULL,
    topic VARCHAR(120) NOT NULL,
    subject VARCHAR(100) NOT NULL,
    resource_type ENUM('Video','Reading','Practice','Quiz','Example') DEFAULT 'Practice',
    difficulty ENUM('Beginner','Intermediate','Advanced') DEFAULT 'Beginner',
    match_percent FLOAT NOT NULL,
    reason TEXT NOT NULL,
    category ENUM('Recommended For You','Improve Your Weak Areas','Continue Learning','Practice More','Challenge Yourself') DEFAULT 'Recommended For You',
    lesson_id INT,
    course_id INT,
    generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE recommendation_feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recommendation_id INT,
    student_id INT,
    helpful BOOLEAN NOT NULL,
    stars INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recommendation_id) REFERENCES recommendations(id),
    FOREIGN KEY (student_id) REFERENCES students(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
